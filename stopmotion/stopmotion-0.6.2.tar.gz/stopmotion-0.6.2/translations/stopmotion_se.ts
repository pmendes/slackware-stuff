<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="40"/>
        <source>This is the Stopmotion application for creating stop motion animations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="44"/>
        <source>&amp;About</source>
        <translation type="unfinished">&amp;Om</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="47"/>
        <source>Main developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="52"/>
        <source>A&amp;uthors</source>
        <translation type="unfinished">&amp;Utvecklare</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="56"/>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="57"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="58"/>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="59"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="65"/>
        <source>Logo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="67"/>
        <source>Coordinating</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="70"/>
        <source>Testing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="81"/>
        <source>&amp;Thanks To</source>
        <translation type="unfinished">&amp;Tack till</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="86"/>
        <source>&amp;Licence Agreement</source>
        <translation type="unfinished">&amp;Licensbestämmelser</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="88"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="101"/>
        <source>About</source>
        <translation type="unfinished">Om</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="60"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="61"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="62"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="63"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="50"/>
        <source>Contributors</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceTab</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="346"/>
        <source>Below you can set which device Stopmotion should use for grabbing images and displaying video.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="349"/>
        <source>You can select from the auto-detected devices below or add devices yourself. It is not recommended to use devices which is not auto-detected, but feel free to do it if you are an advanced user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="351"/>
        <source>The selected device is recognized as &lt;b&gt;$VIDEODEVICE&lt;/b&gt; under Video Import.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="354"/>
        <source>Name</source>
        <translation type="unfinished">Namn</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="354"/>
        <source>Description</source>
        <translation type="unfinished">Beskrivning</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="357"/>
        <source>&amp;Add</source>
        <translation type="unfinished">&amp;Lägg till</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="358"/>
        <source>&amp;Remove</source>
        <translation type="unfinished">&amp;Ta bort</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="359"/>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Ändra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="362"/>
        <source>Video device settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="363"/>
        <source>Video Device ($VIDEODEVICE): </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="149"/>
        <source>device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportTab</name>
    <message>
        <location filename="" line="7471221"/>
        <source>Active</source>
        <translation type="obsolete">Aktivera</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="410"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="410"/>
        <source>Description</source>
        <translation>Beskrivning</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="413"/>
        <source>&amp;Add</source>
        <translation>&amp;Lägg till</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="414"/>
        <source>&amp;Remove</source>
        <translation>&amp;Ta bort</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="415"/>
        <source>&amp;Edit</source>
        <translation>&amp;Ändra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="97"/>
        <source>Encoder settings</source>
        <translation>Kodar inställningar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="418"/>
        <source>Do you want to be asked for an output file everytime you choose to export?</source>
        <translation>Vill du bli frågad om ett filnamn varje gång du väljer att exportera?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="420"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="421"/>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="422"/>
        <source>Set default output file:</source>
        <translation>Välj standard filnamn:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="423"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="424"/>
        <source>Start encoder:</source>
        <translation>Starta kodare:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="425"/>
        <source>Stop encoder:</source>
        <translation>Stoppa kodare:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="391"/>
        <source>Choose output file</source>
        <translation>Välj filnamn</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;Below you can set which program/process stopmotion should use for encoding the currently active project to a video file.&lt;/p&gt;&lt;p&gt;You can use $IMAGEPATH to represent the image path (absolute path to the directory where the images can be found). You should always use &lt;b&gt;$VIDEOFILE&lt;/b&gt; to represent the output file (the videofile generated by the encoder) in the &lt;b&gt;command line&lt;/b&gt;. This is independent of how you decides to select it (select it for each export or have a default file).&lt;br&gt;&lt;/p&gt;&lt;p&gt; Example with mencoder (converting jpg to mpeg1): &lt;br&gt;mencoder mf://$IMAGEPATH/*.jpg -mf w=640:h=480:fps=12:type=jpg -ovc lavc -lavcopts vcodec=mpeg1video -oac copy -o $VIDEOFILE &lt;br&gt;</source>
        <translation type="obsolete">&lt;p&gt;Nedan kan du ställa in vilket program stopmotion bör använda för att koda det aktuella projektet till en videofil.&lt;/p&gt;&lt;p&gt;Du kan använda $IMAGEPATH för att bestämma bildsökvägen (den absoluta sökvägen till mappen där bilderna kan hittas). Du bör alltid använda &lt;b&gt;$VIDEOFILE&lt;/b&gt; för att bestämma destinationsfilen (videofilen som genererats av kodaren) i &lt;b&gt;kommand prompten&lt;/b&gt;. Detta är oberoende av hur du bestämmer dig för att välja det (välja det för  varje export eller att ha en standardfil).&lt;br&gt;&lt;/p&gt;&lt;p&gt; Exempel med mencoder (konvertera jpg till mpeg1): &lt;br&gt;mencoder mf://$IMAGEPATH/*.jpg -mf w=640:h=480:fps=12:type=jpg -ovc lavc -lavcopts vcodec=mpeg1video -oac copy -o $VIDEOFILE &lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="402"/>
        <source>Below you can set which program/process Stopmotion should use for encoding the currently active project to a video file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="404"/>
        <source>You should always use &lt;b&gt;$IMAGEPATH&lt;/b&gt; and &lt;b&gt;$VIDEOFILE&lt;/b&gt; to represent the image path and the video file, respectively.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="405"/>
        <source>Example with mencoder (jpeg images to mpeg4 video):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExternalCommand</name>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="44"/>
        <source>Input to program:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="54"/>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="60"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="73"/>
        <source>Output from external command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="116"/>
        <source>Result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="113"/>
        <source>Failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="116"/>
        <source>Successfull!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDialog</name>
    <message>
        <location filename="" line="7471221"/>
        <source>Go to home directory</source>
        <translation type="obsolete">Gå till hem mappen</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.ui" line="33"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameBar</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framebar/framebar.cpp" line="125"/>
        <source>Frame number: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FramePreferencesMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="109"/>
        <source>Add &amp;sound</source>
        <translation>Lägg till &amp;ljud</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="110"/>
        <source>&amp;Remove Sound</source>
        <translation>&amp;Ta bort ljud</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="111"/>
        <source>Change name</source>
        <translation>Byt namn</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="112"/>
        <source>Sounds:</source>
        <translation>LJud:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="118"/>
        <source>&lt;h4&gt;Add sound&lt;/h4&gt; &lt;p&gt;With this button you can &lt;em&gt;add sounds&lt;/em&gt; to the selected frame.&lt;/p&gt; &lt;p&gt;The sound will begin playing when this frame is shown and play until it is done.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Lägg till ljud&lt;/h4&gt;&lt;p&gt;Med den här knappen kan du &lt;em&gt;lägga till ljud&lt;/em&gt; till den valda bildrutan.&lt;/p&gt;&lt;p&gt;Ljudet kommer börja spelas när den här bildrutan visas och spelas till den är slut.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="125"/>
        <source>&lt;h4&gt;Remove sound&lt;/h4&gt; &lt;p&gt;With this button you can &lt;em&gt;remove&lt;/em&gt; the selected sound from this frame.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ta bort  ljud&lt;/h4&gt;&lt;p&gt;Med den här knappen kan du &lt;em&gt;ta bort&lt;/em&gt;det valda ljudet från bildrutan.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="133"/>
        <source>&lt;h4&gt;Change name&lt;/h4&gt; &lt;p&gt;With this button you can change the name of the selected sound. &lt;BR&gt;The name of the sound has no other effect than making it easier work with the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Byt namn&lt;/h4&gt;&lt;p&gt;Med den här knappen kan du byta namnet på det valda ljudet.&lt;BR&gt;Namnet på ljudet har ingen annan effekt än att göra det lättare att jobba med animationen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="141"/>
        <source>&lt;h4&gt;Sounds&lt;/h4&gt; &lt;p&gt;This lists shows all the sounds connected to this frame.&lt;/p&gt;&lt;p&gt;The sounds will begin playing when this frame is shown and play until they are done.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ljud&lt;/h4&gt; &lt;p&gt;Den här listan visar alla ljud med kopplingar till den här bildrutan.&lt;/p&gt;&lt;p&gt;Ljuden kommer att börja spelas när den här bildrutan visas och spelas tills de är färdiga.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>FrameView</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="444"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="435"/>
        <source>Grabbing failed. This may happen if you try
to grab from an invalid device. Please check
your grabber settings in the preferences menu.</source>
        <translation>Hämtning misslyckades. Detta kan hända om
du försöker hämta från en ogiltig enhet.
Var god kontrollera hämatinställningarna i
inställningsmenyn.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="446"/>
        <source>You have to define an image grabber to use.
This can be set in the preferences menu.</source>
        <translation>Du måste välja en bildhämtare att använda.
Detta kan ställas in i inställnings menyn.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="360"/>
        <source>No video device selected in the preferences menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="372"/>
        <source>Pre poll command does not exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="386"/>
        <source>You do not have the given grabber installed on your system</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HelpWindow</name>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;New Window</source>
        <translation type="obsolete">&amp;Nytt  Fönster</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Open File</source>
        <translation type="obsolete">&amp;Öppna Fil</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Print</source>
        <translation type="obsolete">&amp;Skriv ut</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Close</source>
        <translation type="obsolete">&amp;Stäng</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Backward</source>
        <translation type="obsolete">&amp;Bakåt</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Forward</source>
        <translation type="obsolete">&amp;Framåt</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Home</source>
        <translation type="obsolete">&amp;Hem</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Add Bookmark</source>
        <translation type="obsolete">Lägg till bokmärke</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;File</source>
        <translation type="obsolete">&amp;Fil</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Go</source>
        <translation type="obsolete">&amp;Gå</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>History</source>
        <translation type="obsolete">Historia</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Bookmarks</source>
        <translation type="obsolete">Bokmärken</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Backward</source>
        <translation type="obsolete">Bakåt</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Forward</source>
        <translation type="obsolete">Framåt</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Home</source>
        <translation type="obsolete">Hem</translation>
    </message>
</context>
<context>
    <name>ImportTab</name>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;Below you can set which program/process stopmotion should use for grabbing images from the webcam, and displaying video.&lt;br&gt; &lt;br&gt; &lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;Nedan kan du välja vilket program/process stopmotion ska använda för att hämta bilder från webkameran och visa videon.&lt;br&gt;&lt;br&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Active</source>
        <translation type="obsolete">Aktiv</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="337"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="337"/>
        <source>Description</source>
        <translation>Beskrivning</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="340"/>
        <source>&amp;Add</source>
        <translation>&amp;Lägg till</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="341"/>
        <source>&amp;Remove</source>
        <translation>&amp;Ta bort</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="342"/>
        <source>&amp;Edit</source>
        <translation>&amp;Ändra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="344"/>
        <source>Import device settings</source>
        <translation>Importera enhets inställningar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="345"/>
        <source>Pre-poll command</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="346"/>
        <source>Start deamon</source>
        <translation>Starta deamon</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="347"/>
        <source>Stop deamon</source>
        <translation>Stoppa deamon</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="332"/>
        <source>Below you can set which program/process Stopmotion should use for grabbing images from the selected device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="334"/>
        <source>You should always use &lt;b&gt;$VIDEODEVICE&lt;/b&gt; and &lt;b&gt;$IMAGEFILE&lt;/b&gt; to represent the video device and the image file, respectively.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LanguageHandler</name>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="82"/>
        <source>English</source>
        <comment>This should be translated to the name of the language you are translating to, in that language. Example: English = Deutsch (Deutsch is &quot;German&quot; in German)</comment>
        <translation>Svenska</translation>
    </message>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="60"/>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="62"/>
        <source>&amp;Translation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="16"/>
        <source>Stopmotion Help Browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="40"/>
        <source>Backward</source>
        <translation type="unfinished">Bakåt</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="50"/>
        <source>Forward</source>
        <translation type="unfinished">Framåt</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="86"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindowGUI</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="159"/>
        <source>Ready to rumble ;-)</source>
        <translation>Redo att köra igång ;-)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="473"/>
        <source>&amp;New</source>
        <translation>&amp;Ny</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="474"/>
        <source>&amp;Open</source>
        <translation>&amp;Öppna</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="561"/>
        <source>&lt;h4&gt;Open&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Opens&lt;/em&gt; a Stopmotion project file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Öppna&lt;/h4&gt;&lt;p&gt;&lt;em&gt;Öppnar&lt;/em&gt; en Stopmotion projektfil.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="475"/>
        <source>&amp;Save</source>
        <translation>&amp;Spara</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="476"/>
        <source>Save &amp;As</source>
        <translation>Spara &amp;Som</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="479"/>
        <source>&amp;Quit</source>
        <translation>&amp;Avsluta</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="602"/>
        <source>&lt;h4&gt;Quit&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Quits&lt;/em&gt; the program.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Avsluta&lt;/h4&gt;&lt;p&gt;&lt;em&gt;Avslutar&lt;/em&gt; programmet.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="504"/>
        <source>&amp;File</source>
        <translation>&amp;Arkiv</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="480"/>
        <source>&amp;Undo</source>
        <translation>&amp;Ångra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="613"/>
        <source>&lt;h4&gt;Undo&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Undoes&lt;/em&gt; your last operation. You can press undo several time to undo earlier operations.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ångra&lt;/h4&gt;&lt;p&gt;&lt;em&gt;Ångrar&lt;/em&gt; din senaste handling. Du kan trycka på ångraknappen flera gånger för att ångra tidigare hanlingar.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="481"/>
        <source>Re&amp;do</source>
        <translation>&amp;Gör om </translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="622"/>
        <source>&lt;h4&gt;Redo&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Redoes&lt;/em&gt; your last operation. You can press redo several times to redo several operations.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Gör om&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Gör om&lt;/em&gt; din senaste handling. Du kan trycka på göromknappen flera gånger</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="482"/>
        <source>Cu&amp;t</source>
        <translation>&amp;Klipp ut</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="631"/>
        <source>&lt;h4&gt;Cut&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Cuts&lt;/em&gt; the selected frames out of the animation and adds them to the clipboard so that you can paste them in somewhere else.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Klipp ut&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Klipper ut&lt;/em&gt; de valda bildrutorna ur animationen och lägger till dem till klippbordet så att du kan klistra in dem någon annanstans.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="483"/>
        <source>&amp;Copy</source>
        <translation>K&amp;opiera</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="640"/>
        <source>&lt;h4&gt;Copy&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Copies&lt;/em&gt; the selected frames to the clipboard. You can then paste them in another place.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kopiera&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Kopierar&lt;/em&gt; de valda bildrutorna till klippbordet. Du kan sedan klistra in dem någon annanstans.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="484"/>
        <source>&amp;Paste</source>
        <translation>K&amp;listra in</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="650"/>
        <source>&lt;h4&gt;Paste&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Pastes&lt;/em&gt; the frames which are currently in the clipboard into the selected location.&lt;/p&gt; &lt;p&gt;You can copy/cut images from another programs and then use this option to paste them into this animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Klistra in&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Klistra in&lt;/em&gt; bildrutorna i klippbordet i den valda positionen.&lt;/p&gt; &lt;p&gt;Du kan kopiera/klippa bilder från andra program och sedan använda det här valet för att klistra in den i den här animationen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="485"/>
        <source>&amp;Go to frame</source>
        <translation>&amp;Hoppa till bildruta</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="659"/>
        <source>&lt;h4&gt;Go to frame&lt;/h4&gt; &lt;p&gt;This will bring up a popup-menu at the bottom where you can choose a frame you want to &lt;em&gt;go to&lt;/em&gt;.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Hoppa till bildruta&lt;/h4&gt; &lt;p&gt;Det här kommer öppna en popupmeny på botten av skärmen där du kan välja en bildruta du vill &lt;em&gt;hoppa till&lt;/em&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="533"/>
        <source>&amp;Edit</source>
        <translation>&amp;Ändra</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Languages</source>
        <translation type="obsolete">&amp;Språk</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="528"/>
        <source>&amp;Settings</source>
        <translation>&amp;Inställningar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="487"/>
        <source>What&apos;s &amp;This</source>
        <translation>&amp;Vad är det här</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="679"/>
        <source>&lt;h4&gt;What&apos;s This&lt;/h4&gt; &lt;p&gt;This will give you a WhatsThis mouse cursor which can be used to bring up helpful information like this.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Vad är det här&lt;/h4&gt; &lt;p&gt;Detta kommer ge dig en Vadärdethär muspekare som kan användas till att visa hjälpsam information som det här.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="489"/>
        <source>&amp;About</source>
        <translation>&amp;Om</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="697"/>
        <source>&lt;h4&gt;About&lt;/h4&gt; &lt;p&gt;This will display a small information box where you can read general information as well as the names of the developers behind this excellent piece of software.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Om&lt;/h4&gt; &lt;p&gt;Den här kommer visa en liten informationsruta där du kan läsa generell information såväl som namnen på utvecklarna bakom det här utmärkta programmet.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="535"/>
        <source>&amp;Help</source>
        <translation>H&amp;jälp</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="745"/>
        <source>&lt;h4&gt;FrameBar&lt;/h4&gt; &lt;p&gt;In this area you can see the frames and scenes in the animations and build the animation by moving the them around.&lt;/p&gt;&lt;p&gt;You can switch to the next and the previous frame using the &lt;b&gt;arrow buttons&lt;/b&gt; or &lt;b&gt;x&lt;/b&gt; and &lt;b&gt;z&lt;/b&gt;&lt;/p&gt; </source>
        <translation>&lt;h4&gt;Bildrutsfältet&lt;/h4&gt; &lt;p&gt;I det här fältet kan du se bildrutorna och scenerna i animationen och bygga animationen genom att flytta runt dem.&lt;/p&gt;&lt;p&gt;Du kan byta till nästa och förra bildruta genom att använda &lt;b&gt;piltangenterna&lt;/b&gt; eller &lt;b&gt;x&lt;/b&gt; och &lt;b&gt;&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="735"/>
        <source>&lt;h4&gt;Tool menu&lt;/h4&gt; &lt;p&gt;This is the tool menu where most of the buttons and widgets you will need when working on stop motion animations are located.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Verktygsmenyn&lt;/h4&gt; &lt;p&gt;Det här är  verktygsmenyn, här finns de flesta knappar och verktyg du kommer behöva när du arbetar med animationer.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="729"/>
        <source>&lt;h4&gt;Frame preferences menu&lt;/h4&gt; &lt;p&gt;In this menu you can set preferences for the selected frame/frames, such as &lt;b&gt;subtitles&lt;/b&gt;, &lt;b&gt;sound effects&lt;/b&gt;, etc.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;BIldrutornas inställningsmeny&lt;/h4&gt; &lt;p&gt;I den här  menyn kan du ställa in inställningarna för de valda bildrutorna, t.ex. &lt;b&gt;undertexter&lt;/b&gt;, &lt;b&gt;ljudeffekter&lt;/b&gt;, etc.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="722"/>
        <source>&lt;h4&gt;Go to frame menu&lt;/h4&gt; &lt;p&gt;Here you can specify a framenumber and the program will jump to the specified frame&lt;/p&gt; </source>
        <translation>&lt;h4&gt;Gå till bildrutamenyn&lt;/h4&gt; &lt;p&gt;Här kan du skriva in ett bildrutenummer och programmet kommer att hoppa till den valda bildrutan&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="494"/>
        <source>Go to frame:</source>
        <translation>Gå till bildruta:</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Frame number: 0</source>
        <translation type="obsolete">Bildruta nummer: 0</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="707"/>
        <source>&lt;h4&gt;Frame number&lt;/h4&gt;&lt;p&gt;This area displays the numberof the currently selected frame&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Bildruta nummer&lt;/h4&gt;&lt;p&gt;Här visas den valda bildrutans nummer&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="716"/>
        <source>&lt;h4&gt;FrameView&lt;/h4&gt;&lt;p&gt; In this area you can see the selected frame. You can also play animations in this window by pressing the &lt;b&gt;Play&lt;/b&gt; button.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Bildrutevy&lt;/h4&gt;&lt;p&gt; Här kan du se den valda bildrutan. Du kan också spela upp animationen i det här fönstret genom att trycka på &lt;b&gt;Spela&lt;/b&gt; knappen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="755"/>
        <source>Unsaved changes</source>
        <translation>Osparade ändringar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="756"/>
        <source>There are unsaved changes. Do you want to save?</source>
        <translation>Det  finns osparade ändringar. Vill du spara?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="923"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="923"/>
        <source>&amp;No</source>
        <translation>&amp;Nej</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Save File</source>
        <translation type="obsolete">Spara Fil</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;This is the stopmotion application for creating stopmotion animations.&lt;/p&gt;&lt;p&gt;(c) 2005, Fredrik Berg Kj&#xf8;lstad and Bj&#xf8;rn Erik Nilsen&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;Det här är animationsprogrammet för att skapa animationer.&lt;/p&gt;&lt;p&gt;(c) 2005, Fredrik Berg Kjølstad and Bjørn Erik Nilsen&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>A&amp;uthors</source>
        <translation type="obsolete">&amp;Utvecklare</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Thanks To</source>
        <translation type="obsolete">&amp;Tack till</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Licence Agreement</source>
        <translation type="obsolete">&amp;Licensbestämmelser</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="477"/>
        <source>Video</source>
        <translation>VIdeo</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="517"/>
        <source>&amp;Export</source>
        <translation>&amp;Exportera</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="552"/>
        <source>&lt;h4&gt;New&lt;/h4&gt; &lt;p&gt;Creates a &lt;em&gt;new&lt;/em&gt; project.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ny&lt;/h&gt; &lt;p&gt;Skapar ett &lt;em&gt;nytt&lt;/em&gt; projekt.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="571"/>
        <source>&lt;h4&gt;Save&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Saves&lt;/em&gt; the current animation as a Stopmotion project file. &lt;BR&gt;If this project has been saved before it will automaticly be saved to the previously selected file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Spara&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Sparar&lt;/em&gt;animationen som Stopmotionprojektfil. &lt;BR&gt;Om det här projektet har sparats förut kommer det automatiskt sparas till den tidigare valda filen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="580"/>
        <source>&lt;h4&gt;Save As&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Saves&lt;/em&gt; the current animation as a Stopmotion project file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Spara som&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Sparar&lt;/em&gt; den valda animationen som Stopmotionprojektfil.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="589"/>
        <source>&lt;h4&gt;Video&lt;/h4&gt; &lt;p&gt;Exports the current project as &lt;em&gt;video&lt;/em&gt;.&lt;/p&gt;You will be given a wizard to guide you.</source>
        <translation>&lt;h4&gt;Video&lt;/h4&gt; &lt;p&gt;Exporterar det aktuella projektet som &lt;em&gt;video&lt;/em&gt;.&lt;/p&gt;Du kommer att få en guide till hjälp.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="596"/>
        <source>&lt;h4&gt;Cinerella&lt;/h4&gt; &lt;p&gt;Exports the current animation as a &lt;em&gt;Cinerella&lt;/em&gt; project.&lt;/p&gt;You will be given a wizard to guide you.</source>
        <translation>&lt;h4&gt;Cinerella&lt;/h4&gt; &lt;p&gt;Exporterar den aktuella animationen som &lt;/em&gt;Cinerella&lt;/em&gt; projekt.&lt;/p&gt;Du kommer att få en guide som hjälp.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="478"/>
        <source>Cinelerra</source>
        <translation>Cinelerra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="486"/>
        <source>&amp;Configure Stopmotion</source>
        <translation>&amp;Konfigurera Stopmotion</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="1113"/>
        <source>Open &amp;Recent</source>
        <translation>Öppna &amp;Tidigare</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="556"/>
        <source>New project</source>
        <translation>Nytt projekt</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="564"/>
        <source>Open project</source>
        <translation>Öppna projekt</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="574"/>
        <source>Save project</source>
        <translation>Spara projekt</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="583"/>
        <source>Save project As</source>
        <translation>Spara projekt som</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="605"/>
        <source>Quit</source>
        <translation>Avsluta</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="616"/>
        <source>Undo</source>
        <translation>Ångra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="625"/>
        <source>Redo</source>
        <translation>Gör om</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="634"/>
        <source>Cut</source>
        <translation>Klipp ut</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="643"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="653"/>
        <source>Paste</source>
        <translation>Klistra in</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="662"/>
        <source>Go to frame</source>
        <translation>Gå till bildruta</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="668"/>
        <source>&lt;h4&gt;Configure Stopmotion&lt;/h4&gt; &lt;p&gt;This will opens a window where you can &lt;em&gt;configure&lt;/em&gt; Stopmotion with various input and output devices.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Konfigurera Stopmotion&lt;/h4&gt; &lt;p&gt;Öppnar ett fönster där du kan &lt;em&gt;konfigurera&lt;/em&gt; Stopmotion med olika in- och utgångsenheter.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="671"/>
        <source>Configure Stopmotion</source>
        <translation>Konfigurera Stopmotion</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="682"/>
        <source>What&apos;s This</source>
        <translation>Vad är det här</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="700"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="920"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="871"/>
        <source>Cannot find any registered encoder to be used for
video export. This can be setted in the preferences
menu. Export to video will not be possible until you
have setted an encoder to use. Do you want to set it now?</source>
        <translation>Kan inte hitta någon registrerad kodare för att
exportera video. Detta kan ställas ni i inställningar
menyn. Det kommer inte att gå att  exportera till
video förräns du ställt in vilken kodare du vill använda.
Vill du ställa in det nu?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="901"/>
        <source>Export to video file</source>
        <translation>Exportera till videofil</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="922"/>
        <source>The registered encoder is not valid. Do you want
to check your settings in the preferences menu?</source>
        <translation>Den registrerade kodaren fungerar inte. Vill du
kontrollera inställningarna i inställngsmenyn?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="936"/>
        <source>Export to file</source>
        <translation>Exportera till fil</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="687"/>
        <source>&lt;h4&gt;Help&lt;/h4&gt; &lt;p&gt;This button will bring up a dialog with the Stopmotion manual&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Hjälp&lt;/h4&gt; &lt;p&gt;Den här knappen visar ruta med Stopmotions bruksanvisning&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="690"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;&lt;b&gt;Main developers&lt;/b&gt;&lt;br&gt;Fredrik Berg Kj&#xf8;lstad &amp;lt;fredrikbk@hotmail.com&amp;gt;&lt;br&gt;Bj&#xf8;rn Erik Nilsen &amp;lt;bjoern.nilsen@bjoernen.com&amp;gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&lt;b&gt;Utvecklare&lt;/b&gt;&lt;br&gt;Fredrik Berg Kjølstad &amp;lt;fredrikbk@hotmail.com&amp;gt;&lt;br&gt;Bjørn Erik Nilsen &amp;lt;bjoern.nilsen@bjoernen.com&amp;gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Stopmotion User Manual</source>
        <translation type="obsolete">Stopmotion Användar Manual</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;&lt;b&gt;Coordinating&lt;/b&gt;&lt;br&gt;Herman Robak &amp;lt;herman@skolelinux.no&amp;gt;&lt;br&gt;&#xd8;yvind Kol&#xe5;s &amp;lt;pippin@gimp.org&amp;gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Testing&lt;/b&gt;&lt;br&gt;Tore Sinding Bekkedal &amp;lt;toresbe@ifi.uio.no&amp;gt;&lt;br&gt;Finn Arne Johansen &amp;lt;faj@bzz.no&amp;gt;&lt;br&gt;Halvor Borgen &amp;lt;halvor.borgen@hig.no&amp;gt;&lt;br&gt;Bj&#xf8;rn Are Hansen &amp;lt;post@bahansen.net&amp;gt;&lt;br&gt;John Steinar Bild&#xf8;y &amp;lt;johnsbil@haldenfriskole.no&amp;gt;&lt;br&gt;Ole-Anders Andreassen &amp;lt;ole-anders.andreassen@sunndal.kommune.no&amp;gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Translation&lt;/b&gt;&lt;br&gt;George Helebrant &amp;lt;helb@skatekralovice.com&amp;gt; (Czech)&lt;br&gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&lt;b&gt;Koordninering&lt;/b&gt;&lt;br&gt;Herman Robak &amp;lt;herman@skolelinux.no&amp;gt;&lt;br&gt;Øyvind Kolås &amp;lt;pippin@gimp.org&amp;gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Testing&lt;/b&gt;&lt;br&gt;Tore Sinding Bekkedal &amp;lt;toresbe@ifi.uio.no&amp;gt;&lt;br&gt;Finn Arne Johansen &amp;lt;faj@bzz.no&amp;gt;&lt;br&gt;Halvor Borgen &amp;lt;halvor.borgen@hig.no&amp;gt;&lt;br&gt;Bjørn Are Hansen &amp;lt;post@bahansen.net&amp;gt;&lt;br&gt;John Steinar Bildøy &amp;lt;johnsbil@haldenfriskole.no&amp;gt;&lt;br&gt;Ole-Anders Andreassen &amp;lt;ole-anders.andreassen@sunndal.kommune.no&amp;gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Translation&lt;/b&gt;&lt;br&gt;George Helebrant &amp;lt;helb@skatekralovice.com&amp;gt; (Czech)&lt;br&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="493"/>
        <source>Frame number: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="778"/>
        <source>Choose project file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="837"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModelHandler</name>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="53"/>
        <source>Choose frames to add</source>
        <translation>Välj bildrutor att lägga till</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="143"/>
        <source>Removed the selected frame</source>
        <translation>Tog bort de valda bildrutorna</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="216"/>
        <source>Warning</source>
        <translation type="unfinished">Varning</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="184"/>
        <source>You do not have Gimp installed on your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="195"/>
        <source>There is no active frame to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="203"/>
        <source>The active frame is corrupt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="217"/>
        <source>Failed to start Gimp!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="116"/>
        <source>Video &amp;Import</source>
        <translation>Video &amp;Import</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="117"/>
        <source>Video &amp;Export</source>
        <translation>Video &amp;Export</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="111"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="112"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="113"/>
        <source>Preferences Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="115"/>
        <source>Video &amp;Device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtFrontend</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="152"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="156"/>
        <source>Fatal</source>
        <translation>Fatal</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="70"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Progress</source>
        <translation type="obsolete">Process</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="222"/>
        <source>vgrabbj VGA singleshot</source>
        <translation>vgrabbj VGA singelbild</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="230"/>
        <source>vgrabbj VGA deamon</source>
        <translation>vgrabbj VGA deamon</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="232"/>
        <source>Starts vgrabbj as a deamon. Pretty fast.</source>
        <translation>Startar vgrabbj som deamon. Ganska snabb.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="339"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Yes</source>
        <translation type="obsolete">&amp;Ja</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;No</source>
        <translation type="obsolete">&amp;Nej</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="224"/>
        <source>The simplest setting. Fairly slow</source>
        <translation>Den enklaste inställningen. Relativt långsam</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="274"/>
        <source>Exports from jpeg images to mpeg1 video</source>
        <translation>Exporterar från jpeg bilder till mpeg1 video</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="190"/>
        <source>A newer version of the preferences file with few more default
values exists. Do you want to use this one? (Your old preferences
 will be saved in ~/.stopmotion/preferences.xml.OLD)</source>
        <translation>En nyare version av inställningsfilen med ett par fler
grundvärden finns. Vill du använda den? (Dina gamla inställningar
kommer sparas i ~/.stopmotion/preferences.xml.OLD)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="283"/>
        <source>Exports from jpeg images to mpeg2 video</source>
        <translation>Exporterar från jpeg bilder till mpeg2 video</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="301"/>
        <source>Exports from jpeg images to mpeg4 video</source>
        <translation>Exporterar från jpeg bilder till mpeg4 video</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="257"/>
        <source>dvgrab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="241"/>
        <source>Grabbing from DV-cam. (EXPERIMENTAL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="249"/>
        <source>videodog singleshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="251"/>
        <source>Videodog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="259"/>
        <source>Grabbing from DV-cam.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RunAnimationHandler</name>
    <message>
        <location filename="../src/application/runanimationhandler.cpp" line="90"/>
        <source>Running animation</source>
        <translation>Spelande animation</translation>
    </message>
</context>
<context>
    <name>SoundHandler</name>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="45"/>
        <source>Sounds (*.ogg)</source>
        <translation>Ljud (*.ogg)</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="78"/>
        <source>Sound name</source>
        <translation>Ljudnamn</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="78"/>
        <source>Enter the name of the sound:</source>
        <translation>Skriv in namnet på ljudet:</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="45"/>
        <source>Choose sound file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolsMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="210"/>
        <source>FPS chooser</source>
        <translation>FPS väljare</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="294"/>
        <source>&lt;h4&gt;FPS chooser&lt;/h4&gt; &lt;p&gt;By changing the value in this chooser you set which speed the animation in the &lt;b&gt;FrameView&lt;/b&gt; should run at.&lt;/p&gt; &lt;p&gt;To start an animation press the &lt;b&gt;Run Animation&lt;/b&gt; button.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;FPS väljare&lt;/h4&gt; &lt;p&gt;Genom att ändra värdet här väljer du vilken fart animationen i &lt;b&gt;bildrutevyn&lt;/b&gt; kommer att spelas.&lt;/p&gt; &lt;p&gt;För att starta animationen klicka &lt;b&gt;Kör Animationen&lt;/b&gt; knappen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="211"/>
        <source>Number of images:</source>
        <translation>Antal bilder:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="214"/>
        <source>Mix</source>
        <translation>Mix</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="215"/>
        <source>Diff</source>
        <translation>Diff</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="216"/>
        <source>Playback</source>
        <translation>Spela upp</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="230"/>
        <source>&lt;h4&gt;Add Frames (CTRL+F)&lt;/h4&gt; &lt;p&gt;Click on this button to &lt;em&gt;add&lt;/em&gt; frames to the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Lägg till bildrutor (CTRL+F)&lt;/h4&gt; &lt;p&gt;Klicka på den här knappen för att  &lt;em&gt;lägga till&lt;/em&gt; bildrutor till animationen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="237"/>
        <source>&lt;h4&gt;Remove Selection (Delete)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;remove&lt;/em&gt; the selected frames from the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ta bort markering (Delete)&lt;/h4&gt; &lt;p&gt;Klicka på den här knappen för att &lt;em&gt;ta bort&lt;/em&gt; de valda bildrutorna från animationen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="244"/>
        <source>&lt;h4&gt;New Scene (CTRL+E)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;create&lt;/em&gt; a new &lt;em&gt;scene&lt;/em&gt; to the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ny Scen (CTRL+E)&lt;/h4&gt; &lt;p&gt;Klicka på den här knappen för att &lt;em&gt;skapa&lt;/em&gt; en ny &lt;em&gt;scen&lt;/em&gt; i animationen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="251"/>
        <source>&lt;h4&gt;Remove Scene (SHIFT+Delete)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;remove&lt;/em&gt; the selected scene from the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ta bort Scen (SHIFT+Delete)&lt;/h4&gt; &lt;p&gt;Klicka på den här knappen för att &lt;em&gt;ta bort&lt;/em&gt; den valda scenen från animationen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="257"/>
        <source>&lt;h4&gt;Toggle camera on/off (C)&lt;/h4&gt; &lt;p&gt;Click this button to toggle the camera on and off&lt;/p&gt; </source>
        <translation>&lt;h4&gt;Slå av/på kameran (C)&lt;/h4&gt; &lt;p&gt;Klicka på den här knappen för att slå av och på kameran&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="272"/>
        <source>&lt;h4&gt;Capture Frame (Space)&lt;/h4&gt; &lt;p&gt;Click on this button to &lt;em&gt;capture&lt;/em&gt; a frame from the camera an put it in the animation&lt;/p&gt; &lt;p&gt; This can also be done by pressing the &lt;b&gt;Space key&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Fånga Bildruta (Mellanslag)&lt;/h4&gt; &lt;p&gt;Klicka på den här knappen för att &lt;em&gt;fånga&lt;/em&gt; en bildruta från kameran och lägga till den till animationen&lt;/p&gt; &lt;p&gt; Du kan även trycka på &lt;b&gt;mellanslag&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="283"/>
        <source>&lt;h4&gt;Number of images&lt;/h4&gt; &lt;p&gt;By changing the value in this slidebar you can specify how many images backwards in the animation which should be mixed on top of the camera or if you are in playback mode: how many images to play. &lt;/p&gt; &lt;p&gt;By mixing the previous image(s) onto the camera you can more easily see how the next shot will be in relation to the other, therby making a smoother stop motion animation!&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Antal bilder&lt;/h4&gt; &lt;p&gt;Genom att ändra värdet i den här barometern kan du specificera hur många bilder bakåt i animationen som ska mixas med kameran eller om du är i uppspelningsläge: hur många bilder som ska spelas.&lt;/p&gt; &lt;p&gt;Genom att mixa tidigare bilder med kameran kan du enklare se hur nästa bild kommer att bli i relation till de andra, därmed skapa en finare animation!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="298"/>
        <source>&lt;h4&gt;Play animation (K, P)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Spela animation (K,P)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="301"/>
        <source>&lt;h4&gt;Stop animation (K, P)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Stoppa animation (K,P)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="304"/>
        <source>&lt;h4&gt;Previous frame (J, Left)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Förra bildrutan (J, Vänsterpil)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="307"/>
        <source>&lt;h4&gt;Next frame (L, Right)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Nästa bildruta (L, Högerpil)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="310"/>
        <source>&lt;h4&gt;Previous scene (I)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Tidigare scen (I)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="313"/>
        <source>&lt;h4&gt;Next scene (O)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Nästa scen (0)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="318"/>
        <source>&lt;h4&gt;Loop animation (CTRL+L)&lt;/h4&gt; &lt;p&gt;With this button you can set whether you want the animation to play to the end, or to loop indefinetly.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Loopa animation (CTRL+L)&lt;/h4&gt; &lt;p&gt;Med denna kanpp kan du ställa in om du vill att animationen ska spelas till slutet eller loopas i oändlighet.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="408"/>
        <source>Notice</source>
        <translation>Notera</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="411"/>
        <source>Playback only currently works when running the grabber 
as a deamon. Go to the preferences menu (CTRL+P) to switch 
to running the image grabbing as a deamon.</source>
        <translation>Uppspelning fungerar för tillfället bara när hämtaren körs
som deamon. Gå till inställningsmenyn (CTRL+P) för att byta
till att köra bildhämtningen som deamon.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="217"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="221"/>
        <source>Pr sec</source>
        <translation>Per sec</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="222"/>
        <source>Pr min</source>
        <translation>Per min</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="223"/>
        <source>Pr hr</source>
        <translation>Per timme</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="264"/>
        <source>&lt;h4&gt;Launch Gimp&lt;/h4&gt; &lt;p&gt;Click this button to open the active frame in Gimp&lt;/p&gt; &lt;p&gt;Note that you can also drag images from the frame bar and drop them on Gimp&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
