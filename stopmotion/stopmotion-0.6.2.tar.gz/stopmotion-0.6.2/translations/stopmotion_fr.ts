<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="44"/>
        <source>&amp;About</source>
        <translation type="unfinished">A &amp;propos</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="47"/>
        <source>Main developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="52"/>
        <source>A&amp;uthors</source>
        <translation type="unfinished">A&amp;uteurs</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="56"/>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="57"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="58"/>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="59"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="65"/>
        <source>Logo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="67"/>
        <source>Coordinating</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="70"/>
        <source>Testing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="81"/>
        <source>&amp;Thanks To</source>
        <translation type="unfinished">&amp;Remerciements à</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="86"/>
        <source>&amp;Licence Agreement</source>
        <translation type="unfinished">Accord de &amp;license</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="88"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="101"/>
        <source>About</source>
        <translation type="unfinished">A propos</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="40"/>
        <source>This is the Stopmotion application for creating stop motion animations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="60"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="61"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="62"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="63"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="50"/>
        <source>Contributors</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceTab</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="346"/>
        <source>Below you can set which device Stopmotion should use for grabbing images and displaying video.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="349"/>
        <source>You can select from the auto-detected devices below or add devices yourself. It is not recommended to use devices which is not auto-detected, but feel free to do it if you are an advanced user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="351"/>
        <source>The selected device is recognized as &lt;b&gt;$VIDEODEVICE&lt;/b&gt; under Video Import.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="354"/>
        <source>Name</source>
        <translation type="unfinished">Nom</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="354"/>
        <source>Description</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="357"/>
        <source>&amp;Add</source>
        <translation type="unfinished">&amp;Ajouter</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="358"/>
        <source>&amp;Remove</source>
        <translation type="unfinished">&amp;Supprimer</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="359"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="362"/>
        <source>Video device settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="363"/>
        <source>Video Device ($VIDEODEVICE): </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="149"/>
        <source>device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportTab</name>
    <message>
        <location filename="" line="135122560"/>
        <source>Active</source>
        <translation type="obsolete">Activé</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="410"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="410"/>
        <source>Description</source>
        <translation>Description</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="413"/>
        <source>&amp;Add</source>
        <translation>&amp;Ajouter</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="414"/>
        <source>&amp;Remove</source>
        <translation>&amp;Supprimer</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="415"/>
        <source>&amp;Edit</source>
        <translation>&amp;Modifier</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="97"/>
        <source>Encoder settings</source>
        <translation>Paramètres de l&apos;encodeur</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="418"/>
        <source>Do you want to be asked for an output file everytime you choose to export?</source>
        <translation>Voulez-vous choisir le fichier destination à chaque export ?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="420"/>
        <source>Yes</source>
        <translation>Oui</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="421"/>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="422"/>
        <source>Set default output file:</source>
        <translation>Définir le fichier destination par défaut :</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="423"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="424"/>
        <source>Start encoder:</source>
        <translation>Lancer l&apos;encodeur :</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="425"/>
        <source>Stop encoder:</source>
        <translation>Arrêter l&apos;encodeur :</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="391"/>
        <source>Choose output file</source>
        <translation>Choisir le fichier destination</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&lt;p&gt;Below you can set which program/process stopmotion should use for encoding the currently active project to a video file.&lt;/p&gt;&lt;p&gt;You can use $IMAGEPATH to represent the image path (absolute path to the directory where the images can be found). You should always use &lt;b&gt;$VIDEOFILE&lt;/b&gt; to represent the output file (the videofile generated by the encoder) in the &lt;b&gt;command line&lt;/b&gt;. This is independent of how you decides to select it (select it for each export or have a default file).&lt;br&gt;&lt;/p&gt;&lt;p&gt; Example with mencoder (converting jpg to mpeg1): &lt;br&gt;mencoder mf://$IMAGEPATH/*.jpg -mf w=640:h=480:fps=12:type=jpg -ovc lavc -lavcopts vcodec=mpeg1video -oac copy -o $VIDEOFILE &lt;br&gt;</source>
        <translation type="obsolete">&lt;p&gt;Vous pouvez sélectionner ci-dessous quel programme / processus stopmotion doit utiliser pour encoder le projet en cours en un fichier vidéo.&lt;/p&gt;&lt;p&gt;Dans la ligne de commande, vous pouvez utiliser des variables.&lt;b&gt;$IMAGEPATH&lt;/b&gt; représente le chemin vers les images (chemin absolu vers le dossier contenant les images). &lt;b&gt;$VIDEOFILE&lt;/b&gt; représente le fichier destination (le fichier vidéo généré par l&apos;encodeur). Ceci est indépendant du fait de sélectionner le fichier à chaque export ou d&apos;utiliser un fichier par défaut.&lt;br&gt;&lt;/p&gt;&lt;p&gt;Exemple avec mencoder (conversion de jpg vers mpeg1): &lt;br&gt;mencoder mf://$IMAGEPATH/*.jpg -mf w=640:h=480:fps=12:type=jpg -ovc lavc -lavcopts vcodec=mpeg1video -oac copy -o $VIDEOFILE &lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="402"/>
        <source>Below you can set which program/process Stopmotion should use for encoding the currently active project to a video file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="404"/>
        <source>You should always use &lt;b&gt;$IMAGEPATH&lt;/b&gt; and &lt;b&gt;$VIDEOFILE&lt;/b&gt; to represent the image path and the video file, respectively.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="405"/>
        <source>Example with mencoder (jpeg images to mpeg4 video):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExternalCommand</name>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="44"/>
        <source>Input to program:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="54"/>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="60"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="73"/>
        <source>Output from external command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="116"/>
        <source>Result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="113"/>
        <source>Failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="116"/>
        <source>Successfull!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDialog</name>
    <message>
        <location filename="" line="135122560"/>
        <source>Go to home directory</source>
        <translation type="obsolete">Aller au dossier personnel</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.ui" line="33"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameBar</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framebar/framebar.cpp" line="125"/>
        <source>Frame number: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FramePreferencesMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="109"/>
        <source>Add &amp;sound</source>
        <translation>Ajouter un &amp;son</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="110"/>
        <source>&amp;Remove Sound</source>
        <translation>Supp&amp;rimer un son</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="111"/>
        <source>Change name</source>
        <translation>Changer le nom</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="112"/>
        <source>Sounds:</source>
        <translation>Sons :</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="118"/>
        <source>&lt;h4&gt;Add sound&lt;/h4&gt; &lt;p&gt;With this button you can &lt;em&gt;add sounds&lt;/em&gt; to the selected frame.&lt;/p&gt; &lt;p&gt;The sound will begin playing when this frame is shown and play until it is done.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ajouter un son&lt;/h4&gt; &lt;p&gt;Avec ce bouton, vous pouvez &lt;em&gt;ajouter un son&lt;/em&gt; à l&apos;image sélectionnée.&lt;/p&gt;&lt;p&gt;Le son va être joué quand cette image apparait, et jusqu&apos;à ce qu&apos;il soit terminé.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="125"/>
        <source>&lt;h4&gt;Remove sound&lt;/h4&gt; &lt;p&gt;With this button you can &lt;em&gt;remove&lt;/em&gt; the selected sound from this frame.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Supprimer un son&lt;/h4&gt; &lt;p&gt;Avec ce bouton, vous pouvez &lt;em&gt;supprimer&lt;/em&gt; le son sélectionné de l&apos;image.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="133"/>
        <source>&lt;h4&gt;Change name&lt;/h4&gt; &lt;p&gt;With this button you can change the name of the selected sound. &lt;BR&gt;The name of the sound has no other effect than making it easier work with the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Changer le nom&lt;/h4&gt; &lt;p&gt;Avec ce bouton, vous pouvez changer le nom du son sélectionné. &lt;BR&gt;Le nom du son n&apos;a aucun autre effet que de faciliter le travail avec l&apos;animation.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="141"/>
        <source>&lt;h4&gt;Sounds&lt;/h4&gt; &lt;p&gt;This lists shows all the sounds connected to this frame.&lt;/p&gt;&lt;p&gt;The sounds will begin playing when this frame is shown and play until they are done.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Sons&lt;/h4&gt; &lt;p&gt;Ceci affiche une une liste de  tous les sons associés à cette image.&lt;/p&gt;&lt;p&gt;Les sons sont joués quand cette image apparait et jusqu&apos;à ce ce qu&apos;ils soient terminés.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>FrameView</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="444"/>
        <source>Warning</source>
        <translation>Attention</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="435"/>
        <source>Grabbing failed. This may happen if you try
to grab from an invalid device. Please check
your grabber settings in the preferences menu.</source>
        <translation>La capture a échoué. Ceci peut arriver si vous essayez de capturer 
à partir d&apos;un périphérique non valide. Veuillez vérifier les 
paramètres de capture dans la fenêtre de préférences.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="446"/>
        <source>You have to define an image grabber to use.
This can be set in the preferences menu.</source>
        <translation>Vous devez définir un périphérique de capture.
Ceci peut être fait dans la fenêtre de préférences.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="372"/>
        <source>Pre poll command does not exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="386"/>
        <source>You do not have the given grabber installed on your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="360"/>
        <source>No video device selected in the preferences menu.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HelpWindow</name>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;New Window</source>
        <translation type="obsolete">&amp;Nouvelle fenêtre</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Open File</source>
        <translation type="obsolete">&amp;Ouvrir un fichier</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Print</source>
        <translation type="obsolete">Im&amp;primer</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Close</source>
        <translation type="obsolete">&amp;Fermer</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Backward</source>
        <translation type="obsolete">Pa&amp;ge précédente</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Forward</source>
        <translation type="obsolete">P&amp;age suivante</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Home</source>
        <translation type="obsolete">Table des mati&amp;ères</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>Add Bookmark</source>
        <translation type="obsolete">Ajouter un signet</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;File</source>
        <translation type="obsolete">&amp;Fichier</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Go</source>
        <translation type="obsolete">Al&amp;ler</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>History</source>
        <translation type="obsolete">Historique</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>Bookmarks</source>
        <translation type="obsolete">Signets</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>Backward</source>
        <translation type="obsolete">Page précédente</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>Forward</source>
        <translation type="obsolete">Page suivante</translation>
    </message>
</context>
<context>
    <name>ImportTab</name>
    <message>
        <location filename="" line="135122560"/>
        <source>&lt;p&gt;Below you can set which program/process stopmotion should use for grabbing images from the webcam, and displaying video.&lt;br&gt; &lt;br&gt; &lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;Vous pouvez ci-dessous définir quel programme / processus stopmotion doit utiliser pour capturer des images (à partir d&apos;une caméra par exemple) et afficher la vidéo.&lt;br&gt; &lt;br&gt; &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>Active</source>
        <translation type="obsolete">Activé</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="337"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="337"/>
        <source>Description</source>
        <translation>Description</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="340"/>
        <source>&amp;Add</source>
        <translation>&amp;Ajouter</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="341"/>
        <source>&amp;Remove</source>
        <translation>&amp;Supprimer</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="342"/>
        <source>&amp;Edit</source>
        <translation>&amp;Modifier</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="344"/>
        <source>Import device settings</source>
        <translation>Paramètres d&apos;import</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="345"/>
        <source>Pre-poll command</source>
        <translation>Commande à effectuer avant la capture</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="346"/>
        <source>Start deamon</source>
        <translation>Lancer le démon</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="347"/>
        <source>Stop deamon</source>
        <translation>Arrêter le démon</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="332"/>
        <source>Below you can set which program/process Stopmotion should use for grabbing images from the selected device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="334"/>
        <source>You should always use &lt;b&gt;$VIDEODEVICE&lt;/b&gt; and &lt;b&gt;$IMAGEFILE&lt;/b&gt; to represent the video device and the image file, respectively.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LanguageHandler</name>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="82"/>
        <source>English</source>
        <comment>This should be translated to the name of the language you are translating to, in that language. Example: English = Deutsch (Deutsch is &quot;German&quot; in German)</comment>
        <translation>Français</translation>
    </message>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="60"/>
        <source>English</source>
        <translation>Français</translation>
    </message>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="62"/>
        <source>&amp;Translation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="16"/>
        <source>Stopmotion Help Browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="40"/>
        <source>Backward</source>
        <translation type="unfinished">Page précédente</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="50"/>
        <source>Forward</source>
        <translation type="unfinished">Page suivante</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="86"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindowGUI</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="159"/>
        <source>Ready to rumble ;-)</source>
        <translation>Prêt à vrombir ;-)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="473"/>
        <source>&amp;New</source>
        <translation>&amp;Nouveau</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="474"/>
        <source>&amp;Open</source>
        <translation>&amp;Ouvrir</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="561"/>
        <source>&lt;h4&gt;Open&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Opens&lt;/em&gt; a Stopmotion project file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ouvrir&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Ouvre&lt;/em&gt; un projet Stopmotion.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="475"/>
        <source>&amp;Save</source>
        <translation>&amp;Enregistrer</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="476"/>
        <source>Save &amp;As</source>
        <translation>Enregistrer &amp;sous</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="479"/>
        <source>&amp;Quit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="602"/>
        <source>&lt;h4&gt;Quit&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Quits&lt;/em&gt; the program.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Quitter&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Quitte&lt;/em&gt; le programme Stopmotion.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="504"/>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="480"/>
        <source>&amp;Undo</source>
        <translation>Annu&amp;ler</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="613"/>
        <source>&lt;h4&gt;Undo&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Undoes&lt;/em&gt; your last operation. You can press undo several time to undo earlier operations.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Annuler&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Annule&lt;/em&gt; la dernière action. Vous pouvez presser Annuler plusieurs fois pour annuler plusieurs actions.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="481"/>
        <source>Re&amp;do</source>
        <translation>Re&amp;faire</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="622"/>
        <source>&lt;h4&gt;Redo&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Redoes&lt;/em&gt; your last operation. You can press redo several times to redo several operations.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Refaire&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Refait&lt;/em&gt; la dernière action annulée. Vous pouvez presser Refaire plusieurs fois pour refaire plusieurs actions.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="482"/>
        <source>Cu&amp;t</source>
        <translation>Co&amp;uper</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="631"/>
        <source>&lt;h4&gt;Cut&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Cuts&lt;/em&gt; the selected frames out of the animation and adds them to the clipboard so that you can paste them in somewhere else.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Couper&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Coupe&lt;/em&gt; les images sélectionnées de l&apos;animation et les ajoute au presse-papier pour que vous puissiez les coller ailleurs.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="483"/>
        <source>&amp;Copy</source>
        <translation>Cop&amp;ier</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="640"/>
        <source>&lt;h4&gt;Copy&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Copies&lt;/em&gt; the selected frames to the clipboard. You can then paste them in another place.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Copier&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Copie&lt;/em&gt; les images sélectionnées dans le presse-papier. Vous pouvez alors les coller où vous le souhaitez.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="484"/>
        <source>&amp;Paste</source>
        <translation>C&amp;oller</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="650"/>
        <source>&lt;h4&gt;Paste&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Pastes&lt;/em&gt; the frames which are currently in the clipboard into the selected location.&lt;/p&gt; &lt;p&gt;You can copy/cut images from another programs and then use this option to paste them into this animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Coller&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Colle&lt;/em&gt; les images stockées dans le presse-papier à l&apos;emplacement sélectionné.&lt;/p&gt; &lt;p&gt;Vous pouvez copier / coller des images depuis d&apos;autres programmes et utiliser cette option pour les coller dans cette animation.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="485"/>
        <source>&amp;Go to frame</source>
        <translation>&amp;Aller à l&apos;image</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="659"/>
        <source>&lt;h4&gt;Go to frame&lt;/h4&gt; &lt;p&gt;This will bring up a popup-menu at the bottom where you can choose a frame you want to &lt;em&gt;go to&lt;/em&gt;.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Aller à l&apos;image&lt;/h4&gt; &lt;p&gt;Ceci affiche un menu contextuel où vous pouvez choisir une image où vous souhaitez &lt;em&gt;aller&lt;/em&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="533"/>
        <source>&amp;Edit</source>
        <translation>&amp;Édition</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Languages</source>
        <translation type="obsolete">&amp;Langages</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="528"/>
        <source>&amp;Settings</source>
        <translation>&amp;Paramètres</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="487"/>
        <source>What&apos;s &amp;This</source>
        <translation>&amp;Qu&apos;est-ce que c&apos;est</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="679"/>
        <source>&lt;h4&gt;What&apos;s This&lt;/h4&gt; &lt;p&gt;This will give you a WhatsThis mouse cursor which can be used to bring up helpful information like this.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Qu&apos;est-ce que c&apos;est&lt;/h4&gt; &lt;p&gt;Ceci affiche un curseur de souris spécial qui peut être utilisé pour afficher des informations utiles comme celle-ci.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="489"/>
        <source>&amp;About</source>
        <translation>A &amp;propos</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="697"/>
        <source>&lt;h4&gt;About&lt;/h4&gt; &lt;p&gt;This will display a small information box where you can read general information as well as the names of the developers behind this excellent piece of software.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;A propos&lt;/h4&gt; &lt;p&gt;Ceci affiche une petite fenêtre d&apos;information où vous pouvez lire des informations générales aussi bien que les noms des développeurs qui ont créé cet excellent logiciel.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="535"/>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="745"/>
        <source>&lt;h4&gt;FrameBar&lt;/h4&gt; &lt;p&gt;In this area you can see the frames and scenes in the animations and build the animation by moving the them around.&lt;/p&gt;&lt;p&gt;You can switch to the next and the previous frame using the &lt;b&gt;arrow buttons&lt;/b&gt; or &lt;b&gt;x&lt;/b&gt; and &lt;b&gt;z&lt;/b&gt;&lt;/p&gt; </source>
        <translation> &lt;h4&gt;Barre d&apos;images&lt;/h4&gt; &lt;p&gt;Dans cette zone, vous pouvez voir les images et les scènes de l&apos;animation et les déplacer.&lt;/p&gt;&lt;p&gt;Vous pouvez passer à l&apos;image suivante ou précédente en utilisant les &lt;b&gt;touches fléchées/b&gt; ou &lt;b&gt;x&lt;/b&gt; et &lt;b&gt;z&lt;/b&gt;&lt;/p&gt; </translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="735"/>
        <source>&lt;h4&gt;Tool menu&lt;/h4&gt; &lt;p&gt;This is the tool menu where most of the buttons and widgets you will need when working on stop motion animations are located.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Barre d&apos;outils&lt;/h4&gt; &lt;p&gt;La barre d&apos;outils contient la plupart des boutons dont vous aurez besoin pour travailler sur les animations stopmotion.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="729"/>
        <source>&lt;h4&gt;Frame preferences menu&lt;/h4&gt; &lt;p&gt;In this menu you can set preferences for the selected frame/frames, such as &lt;b&gt;subtitles&lt;/b&gt;, &lt;b&gt;sound effects&lt;/b&gt;, etc.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Barre de préférences des images&lt;/h4&gt; &lt;p&gt;Dans cette zone, vous pouvez définir des préférences pour l&apos;image ou les images séléctionnées, telles que des &lt;b&gt;sous-titres&lt;/b&gt;, des &lt;b&gt;effets sonores&lt;/b&gt;, etc.&lt;/p&gt;u&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="722"/>
        <source>&lt;h4&gt;Go to frame menu&lt;/h4&gt; &lt;p&gt;Here you can specify a framenumber and the program will jump to the specified frame&lt;/p&gt; </source>
        <translation> &lt;h4&gt;Barre Aller à l&apos;image&lt;/h4&gt; &lt;p&gt;Ici vous pouvez spécifier un numéro d&apos;image et le programme sélectionnera l&apos;image correspondante&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="494"/>
        <source>Go to frame:</source>
        <translation>Aller à l&apos;image :</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>Frame number: 0</source>
        <translation type="obsolete">Image numéro : 0</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="707"/>
        <source>&lt;h4&gt;Frame number&lt;/h4&gt;&lt;p&gt;This area displays the numberof the currently selected frame&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Numéro d&apos;image&lt;/h4&gt;&lt;p&gt;Cette zone affiche le numéro de l&apos;image actuellement sélectionnée&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="716"/>
        <source>&lt;h4&gt;FrameView&lt;/h4&gt;&lt;p&gt; In this area you can see the selected frame. You can also play animations in this window by pressing the &lt;b&gt;Play&lt;/b&gt; button.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Cadre de prévisualisation&lt;/h4&gt;&lt;p&gt; Dans cette zone, vous pouvez voir l&apos;image sélectionnée. Vous pouvez aussi voir les animations en pressant le bouton &lt;b&gt;Lecture&lt;/b&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="755"/>
        <source>Unsaved changes</source>
        <translation>Modifications non enregistrées</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="756"/>
        <source>There are unsaved changes. Do you want to save?</source>
        <translation>Il y a des modifications non enregistrées. Voulez-vous enregistrer ?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="923"/>
        <source>&amp;Yes</source>
        <translation>&amp;Oui</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="923"/>
        <source>&amp;No</source>
        <translation>&amp;Non</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>Save File</source>
        <translation type="obsolete">Enregistrer le fichier</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&lt;p&gt;This is the stopmotion application for creating stopmotion animations.&lt;/p&gt;&lt;p&gt;(c) 2005, Fredrik Berg Kj&#xf8;lstad and Bj&#xf8;rn Erik Nilsen&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;Ceci est l&apos;application stopmotion pour créer des animations stopmotion.&lt;/p&gt;&lt;p&gt;(c) 2005,2006, Fredrik Berg Kjølstad et Bjørn Erik Nilsen&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>A&amp;uthors</source>
        <translation type="obsolete">A&amp;uteurs</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Thanks To</source>
        <translation type="obsolete">&amp;Remerciements à</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Licence Agreement</source>
        <translation type="obsolete">Accord de &amp;license</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="477"/>
        <source>Video</source>
        <translation>Vidéo</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="517"/>
        <source>&amp;Export</source>
        <translation>&amp;Exporter</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="552"/>
        <source>&lt;h4&gt;New&lt;/h4&gt; &lt;p&gt;Creates a &lt;em&gt;new&lt;/em&gt; project.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Nouveau&lt;/h4&gt; &lt;p&gt;Crée un &lt;em&gt;nouveau&lt;/em&gt; projet.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="571"/>
        <source>&lt;h4&gt;Save&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Saves&lt;/em&gt; the current animation as a Stopmotion project file. &lt;BR&gt;If this project has been saved before it will automaticly be saved to the previously selected file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Enregistrer&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Enregistre&lt;/em&gt; l&apos;animation courante sous forme de fichier projet Stopmotion. &lt;BR&gt;Si ce projet a été enregistré précédemment, il sera enregistré automatiquement dans le même fichier (écrasement).&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="580"/>
        <source>&lt;h4&gt;Save As&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Saves&lt;/em&gt; the current animation as a Stopmotion project file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Enregistrer sous&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Enregistre&lt;/em&gt; l&apos;animation courante sous forme de fichier projet Stopmotion.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="589"/>
        <source>&lt;h4&gt;Video&lt;/h4&gt; &lt;p&gt;Exports the current project as &lt;em&gt;video&lt;/em&gt;.&lt;/p&gt;You will be given a wizard to guide you.</source>
        <translation>&lt;h4&gt;Vidéo&lt;/h4&gt; &lt;p&gt;Exporte le projet courant vers un fichier &lt;em&gt;vidéo&lt;/em&gt;.&lt;/p&gt;Vous aurez un assistant pour vous guider.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="596"/>
        <source>&lt;h4&gt;Cinerella&lt;/h4&gt; &lt;p&gt;Exports the current animation as a &lt;em&gt;Cinerella&lt;/em&gt; project.&lt;/p&gt;You will be given a wizard to guide you.</source>
        <translation>&lt;h4&gt;Cinerella&lt;/h4&gt; &lt;p&gt;Exporte l&apos;animation courante en tant que projet &lt;em&gt;Cinerella&lt;/em&gt;.&lt;/p&gt;Vous aurez un assistant pour vous guider.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="478"/>
        <source>Cinelerra</source>
        <translation>Cinelerra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="486"/>
        <source>&amp;Configure Stopmotion</source>
        <translation>&amp;Configurer Stopmotion</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="1113"/>
        <source>Open &amp;Recent</source>
        <translation>&amp;Récemment ouvert(s)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="556"/>
        <source>New project</source>
        <translation>Nouveau projet</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="564"/>
        <source>Open project</source>
        <translation>Ouvrir un projet</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="574"/>
        <source>Save project</source>
        <translation>Enregistrer le projet</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="583"/>
        <source>Save project As</source>
        <translation>Enregistrer le projet sous</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="605"/>
        <source>Quit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="616"/>
        <source>Undo</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="625"/>
        <source>Redo</source>
        <translation>Refaire</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="634"/>
        <source>Cut</source>
        <translation>Couper</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="643"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="653"/>
        <source>Paste</source>
        <translation>Coller</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="662"/>
        <source>Go to frame</source>
        <translation>Aller à l&apos;image</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="668"/>
        <source>&lt;h4&gt;Configure Stopmotion&lt;/h4&gt; &lt;p&gt;This will opens a window where you can &lt;em&gt;configure&lt;/em&gt; Stopmotion with various input and output devices.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Configurer Stopmotion&lt;/h4&gt; &lt;p&gt;Ceci ouvre une fenêtre où vous pouvez &lt;em&gt;configurer&lt;/em&gt; Stopmotion ainsi que les périphériques d&apos;entrée et de sortie.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="671"/>
        <source>Configure Stopmotion</source>
        <translation>Configurer Stopmotion</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="682"/>
        <source>What&apos;s This</source>
        <translation>Qu&apos;est-ce que c&apos;est</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="700"/>
        <source>About</source>
        <translation>A propos</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="920"/>
        <source>Warning</source>
        <translation>Attention</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="871"/>
        <source>Cannot find any registered encoder to be used for
video export. This can be setted in the preferences
menu. Export to video will not be possible until you
have setted an encoder to use. Do you want to set it now?</source>
        <translation>Aucun encodeur n&apos;est sélectionné pour l&apos;export vidéo. Ceci peut
être paramétré dans la fenêtre de préférences. L&apos;export vidéo 
ne sera pas possible tant que vous n&apos;aurez pas choisi un 
encodeur. Voulez-vous le faire tout de suite ?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="901"/>
        <source>Export to video file</source>
        <translation>Exporter vers un fichier vidéo</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="922"/>
        <source>The registered encoder is not valid. Do you want
to check your settings in the preferences menu?</source>
        <translation>L&apos;encodeur enregistré n&apos;est pas valide. Voulez-vous vérifier 
vos paramètres dans la fenêtre de préférences ?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="936"/>
        <source>Export to file</source>
        <translation>Exporter vers un fichier</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="687"/>
        <source>&lt;h4&gt;Help&lt;/h4&gt; &lt;p&gt;This button will bring up a dialog with the Stopmotion manual&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Aide&lt;/h4&gt; &lt;p&gt;Ce bouton affiche le manuel utilisateur de Stopmotion&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="690"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&lt;p&gt;&lt;b&gt;Main developers&lt;/b&gt;&lt;br&gt;Fredrik Berg Kj&#xf8;lstad &amp;lt;fredrikbk@hotmail.com&amp;gt;&lt;br&gt;Bj&#xf8;rn Erik Nilsen &amp;lt;bjoern.nilsen@bjoernen.com&amp;gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&lt;b&gt;Développeurs principaux&lt;/b&gt;&lt;br&gt;Fredrik Berg Kjølstad &amp;lt;fredrikbk@hotmail.com&amp;gt;&lt;br&gt;Bjørn Erik Nilsen &amp;lt;bjoern.nilsen@bjoernen.com&amp;gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>Stopmotion User Manual</source>
        <translation type="obsolete">Manuel utilisateur de Stopmotion</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&lt;p&gt;&lt;b&gt;Coordinating&lt;/b&gt;&lt;br&gt;Herman Robak &amp;lt;herman@skolelinux.no&amp;gt;&lt;br&gt;&#xd8;yvind Kol&#xe5;s &amp;lt;pippin@gimp.org&amp;gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Testing&lt;/b&gt;&lt;br&gt;Tore Sinding Bekkedal &amp;lt;toresbe@ifi.uio.no&amp;gt;&lt;br&gt;Finn Arne Johansen &amp;lt;faj@bzz.no&amp;gt;&lt;br&gt;Halvor Borgen &amp;lt;halvor.borgen@hig.no&amp;gt;&lt;br&gt;Bj&#xf8;rn Are Hansen &amp;lt;post@bahansen.net&amp;gt;&lt;br&gt;John Steinar Bild&#xf8;y &amp;lt;johnsbil@haldenfriskole.no&amp;gt;&lt;br&gt;Ole-Anders Andreassen &amp;lt;ole-anders.andreassen@sunndal.kommune.no&amp;gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Translation&lt;/b&gt;&lt;br&gt;George Helebrant &amp;lt;helb@skatekralovice.com&amp;gt; (Czech)&lt;br&gt;Gorazd Bizjak and Matej Lavreni &amp;lt;info@zapstudio.net&amp;gt; (Slovenian)&lt;br&gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&lt;b&gt;Coordination&lt;/b&gt;&lt;br&gt;Herman Robak &amp;lt;herman@skolelinux.no&amp;gt;&lt;br&gt;Øyvind Kolås &amp;lt;pippin@gimp.org&amp;gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Tests&lt;/b&gt;&lt;br&gt;Tore Sinding Bekkedal &amp;lt;toresbe@ifi.uio.no&amp;gt;&lt;br&gt;Finn Arne Johansen &amp;lt;faj@bzz.no&amp;gt;&lt;br&gt;Halvor Borgen &amp;lt;halvor.borgen@hig.no&amp;gt;&lt;br&gt;Bjørn Are Hansen &amp;lt;post@bahansen.net&amp;gt;&lt;br&gt;John Steinar Bildøy &amp;lt;johnsbil@haldenfriskole.no&amp;gt;&lt;br&gt;Ole-Anders Andreassen &amp;lt;ole-anders.andreassen@sunndal.kommune.no&amp;gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Traductions&lt;/b&gt;&lt;br&gt;George Helebrant &amp;lt;helb@skatekralovice.com&amp;gt; (Tchèque)&lt;br&gt;Gorazd Bizjak and Matej Lavreni &amp;lt;info@zapstudio.net&amp;gt; (Slovène)&lt;br&gt;Guillaume Bedot &amp;lt;littletux@zarb.org&amp;gt; (Français)&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="493"/>
        <source>Frame number: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="778"/>
        <source>Choose project file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="837"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModelHandler</name>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="53"/>
        <source>Choose frames to add</source>
        <translation>Choisir les images à ajouter</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="143"/>
        <source>Removed the selected frame</source>
        <translation>L&apos;image sélectionnée a été supprimée</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="216"/>
        <source>Warning</source>
        <translation type="unfinished">Attention</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="184"/>
        <source>You do not have Gimp installed on your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="195"/>
        <source>There is no active frame to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="203"/>
        <source>The active frame is corrupt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="217"/>
        <source>Failed to start Gimp!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="116"/>
        <source>Video &amp;Import</source>
        <translation>&amp;Importer une vidéo</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="117"/>
        <source>Video &amp;Export</source>
        <translation>&amp;Exporter une vidéo</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="111"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="112"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="113"/>
        <source>Preferences Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="115"/>
        <source>Video &amp;Device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtFrontend</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="152"/>
        <source>Warning</source>
        <translation>Attention</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="156"/>
        <source>Fatal</source>
        <translation>Fatal</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="70"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>Progress</source>
        <translation type="obsolete">Progression</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="222"/>
        <source>vgrabbj VGA singleshot</source>
        <translation>Capture VGA unique (vgrabbj)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="230"/>
        <source>vgrabbj VGA deamon</source>
        <translation>Démon de capture VGA (vgrabbj)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="232"/>
        <source>Starts vgrabbj as a deamon. Pretty fast.</source>
        <translation>Lance vgrabbj comme un démon. Plutôt rapide.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="339"/>
        <source>Question</source>
        <translation>Question</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;Yes</source>
        <translation type="obsolete">&amp;Oui</translation>
    </message>
    <message>
        <location filename="" line="135122560"/>
        <source>&amp;No</source>
        <translation type="obsolete">&amp;Non</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="224"/>
        <source>The simplest setting. Fairly slow</source>
        <translation>Le paramétrage le plus simple. Assez lent</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="274"/>
        <source>Exports from jpeg images to mpeg1 video</source>
        <translation>Exporter des images jpeg vers une vidéo mpeg1</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="190"/>
        <source>A newer version of the preferences file with few more default
values exists. Do you want to use this one? (Your old preferences
 will be saved in ~/.stopmotion/preferences.xml.OLD)</source>
        <translation>Une nouvelle version du fichier de préférences, plus complet existe.
Voulez-vous utiliser ce fichier ? ( Votre précédent fichier de préférences
 sera sauvegardé sous ~/.stopmotion/preferences.xml.OLD)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="283"/>
        <source>Exports from jpeg images to mpeg2 video</source>
        <translation>Exporter des images jpeg vers une vidéo mpeg2</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="301"/>
        <source>Exports from jpeg images to mpeg4 video</source>
        <translation>Exporter des images jpeg vers une vidéo mpeg4</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="257"/>
        <source>dvgrab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="241"/>
        <source>Grabbing from DV-cam. (EXPERIMENTAL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="249"/>
        <source>videodog singleshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="251"/>
        <source>Videodog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="259"/>
        <source>Grabbing from DV-cam.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RunAnimationHandler</name>
    <message>
        <location filename="../src/application/runanimationhandler.cpp" line="90"/>
        <source>Running animation</source>
        <translation>Affichage de l&apos;animation en cours</translation>
    </message>
</context>
<context>
    <name>SoundHandler</name>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="45"/>
        <source>Sounds (*.ogg)</source>
        <translation>Sons (*.ogg)</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="78"/>
        <source>Sound name</source>
        <translation>Nom du son</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="78"/>
        <source>Enter the name of the sound:</source>
        <translation>Entrez le nom du son :</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="45"/>
        <source>Choose sound file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolsMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="210"/>
        <source>FPS chooser</source>
        <translation>IPS (images par seconde)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="294"/>
        <source>&lt;h4&gt;FPS chooser&lt;/h4&gt; &lt;p&gt;By changing the value in this chooser you set which speed the animation in the &lt;b&gt;FrameView&lt;/b&gt; should run at.&lt;/p&gt; &lt;p&gt;To start an animation press the &lt;b&gt;Run Animation&lt;/b&gt; button.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;IPS (images par seconde)&lt;/h4&gt; &lt;p&gt;En modifiant cette valeur, vous changez la vitesse de l&apos;animation dans le &lt;b&gt;Cadre de prévisualisation&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Pour lire l&apos;an animation pressez le bouton &lt;b&gt;Lecture de l&apos;animation&lt;/b&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="211"/>
        <source>Number of images:</source>
        <translation>Nombre d&apos;images :</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="214"/>
        <source>Mix</source>
        <translation>Mixer</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="215"/>
        <source>Diff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="216"/>
        <source>Playback</source>
        <translation>Lecture</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="230"/>
        <source>&lt;h4&gt;Add Frames (CTRL+F)&lt;/h4&gt; &lt;p&gt;Click on this button to &lt;em&gt;add&lt;/em&gt; frames to the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ajouter des images (CTRL+F)&lt;/h4&gt; &lt;p&gt;Cliquez sur ce bouton pour &lt;em&gt;ajouter&lt;/em&gt; des images à l&apos;animation.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="237"/>
        <source>&lt;h4&gt;Remove Selection (Delete)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;remove&lt;/em&gt; the selected frames from the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Supprimer la Sélection (Suppr)&lt;/h4&gt; &lt;p&gt;Cliquez sur ce bouton pour &lt;em&gt;supprimer&lt;/em&gt; les images sélectionnées de l&apos;animation.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="244"/>
        <source>&lt;h4&gt;New Scene (CTRL+E)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;create&lt;/em&gt; a new &lt;em&gt;scene&lt;/em&gt; to the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Nouvelle Scène (CTRL+E)&lt;/h4&gt; &lt;p&gt;Cliquez sur ce bouton pour &lt;em&gt;créer&lt;/em&gt; une nouvelle &lt;em&gt;scène&lt;/em&gt; dans l&apos;animation.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="251"/>
        <source>&lt;h4&gt;Remove Scene (SHIFT+Delete)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;remove&lt;/em&gt; the selected scene from the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Supprimer une Scène (MAJ+Suppr)&lt;/h4&gt; &lt;p&gt;Cliquez sur ce bouton pour &lt;em&gt;supprimer&lt;/em&gt; la scène sélectionnée de l&apos;animation.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="257"/>
        <source>&lt;h4&gt;Toggle camera on/off (C)&lt;/h4&gt; &lt;p&gt;Click this button to toggle the camera on and off&lt;/p&gt; </source>
        <translation> &lt;h4&gt;Activer/arrêter la caméra (C)&lt;/h4&gt; &lt;p&gt;Cliquez sur ce bouton pour activer la caméra ou l&apos;arrêter&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="272"/>
        <source>&lt;h4&gt;Capture Frame (Space)&lt;/h4&gt; &lt;p&gt;Click on this button to &lt;em&gt;capture&lt;/em&gt; a frame from the camera an put it in the animation&lt;/p&gt; &lt;p&gt; This can also be done by pressing the &lt;b&gt;Space key&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Capturer une Image (Espace)&lt;/h4&gt; &lt;p&gt;Cliquez sur ce bouton pour &lt;em&gt;capturer&lt;/em&gt; une image depuis la caméra et l&apos;insérer dans l&apos;animation&lt;/p&gt; &lt;p&gt; Pour ce faire, vous pouvez aussi utiliser le raccourci clavier : la &lt;b&gt;touche Espace&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="283"/>
        <source>&lt;h4&gt;Number of images&lt;/h4&gt; &lt;p&gt;By changing the value in this slidebar you can specify how many images backwards in the animation which should be mixed on top of the camera or if you are in playback mode: how many images to play. &lt;/p&gt; &lt;p&gt;By mixing the previous image(s) onto the camera you can more easily see how the next shot will be in relation to the other, therby making a smoother stop motion animation!&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="298"/>
        <source>&lt;h4&gt;Play animation (K, P)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Lecture de l&apos;animation (K, P)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="301"/>
        <source>&lt;h4&gt;Stop animation (K, P)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Arrêt de l&apos;animation (K, P)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="304"/>
        <source>&lt;h4&gt;Previous frame (J, Left)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Image pécédente (J, Gauche)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="307"/>
        <source>&lt;h4&gt;Next frame (L, Right)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Image suivante (L, Droite)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="310"/>
        <source>&lt;h4&gt;Previous scene (I)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Scène précédente (I)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="313"/>
        <source>&lt;h4&gt;Next scene (O)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Scène suivante (O)&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="318"/>
        <source>&lt;h4&gt;Loop animation (CTRL+L)&lt;/h4&gt; &lt;p&gt;With this button you can set whether you want the animation to play to the end, or to loop indefinetly.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Lecture de l&apos;animation en boucle (CTRL+L)&lt;/h4&gt; &lt;p&gt;Avec ce bouton vous pouvez choisir de lire l&apos;animation en boucle infinie plutôt que de la lire une seule fois jusqu&apos;à fin.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="408"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="411"/>
        <source>Playback only currently works when running the grabber 
as a deamon. Go to the preferences menu (CTRL+P) to switch 
to running the image grabbing as a deamon.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="217"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="221"/>
        <source>Pr sec</source>
        <translation>Par sec</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="222"/>
        <source>Pr min</source>
        <translation>Par min</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="223"/>
        <source>Pr hr</source>
        <translation>Par heure</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="264"/>
        <source>&lt;h4&gt;Launch Gimp&lt;/h4&gt; &lt;p&gt;Click this button to open the active frame in Gimp&lt;/p&gt; &lt;p&gt;Note that you can also drag images from the frame bar and drop them on Gimp&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
