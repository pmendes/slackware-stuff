<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="tr_TR">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="44"/>
        <source>&amp;About</source>
        <translation>H&amp;akkında</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="47"/>
        <source>Main developers</source>
        <translation>Sorumlu geliştiriciler</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="52"/>
        <source>A&amp;uthors</source>
        <translation>&amp;Yazarlar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="56"/>
        <source>Translation</source>
        <translation>Çeviri</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="57"/>
        <source>Czech</source>
        <translation>Çekçe</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="58"/>
        <source>Slovenian</source>
        <translation>Slovence</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="59"/>
        <source>French</source>
        <translation>Fransızca</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="65"/>
        <source>Logo</source>
        <translation>Logo</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="67"/>
        <source>Coordinating</source>
        <translation>Koordinasyon</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="70"/>
        <source>Testing</source>
        <translation>Testçiler</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="81"/>
        <source>&amp;Thanks To</source>
        <translation>&amp;Teşekkürler</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="86"/>
        <source>&amp;Licence Agreement</source>
        <translation>&amp;Lisans</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="88"/>
        <source>OK</source>
        <translation>Tamam</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="101"/>
        <source>About</source>
        <translation>Hakkında</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="40"/>
        <source>This is the Stopmotion application for creating stop motion animations.</source>
        <translation>Stopmotion uygulaması stop motion (durdurma tekniği) ile animasyon yapmakta kullanılır.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="60"/>
        <source>German</source>
        <translation>Almanca</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="61"/>
        <source>Portuguese</source>
        <translation>Portekizce</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="62"/>
        <source>Spanish</source>
        <translation>İspanyolca</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="63"/>
        <source>Swedish</source>
        <translation>İsveççe</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="50"/>
        <source>Contributors</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceTab</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="346"/>
        <source>Below you can set which device Stopmotion should use for grabbing images and displaying video.</source>
        <translation>Aşağıda Stopmotion için görüntü yakalama ve video oynatma araçlarını seçebilirsiniz.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="349"/>
        <source>You can select from the auto-detected devices below or add devices yourself. It is not recommended to use devices which is not auto-detected, but feel free to do it if you are an advanced user.</source>
        <translation>Aşağıda bulunmuş aygıtlardan seçebilir ya da kendiniz yeni ekleyebilirsiniz. Deneyimli değilseniz sistem tarafından bulunmamış bir aygıt kullanmaMAnız önerilir, ama seçim sizin.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="351"/>
        <source>The selected device is recognized as &lt;b&gt;$VIDEODEVICE&lt;/b&gt; under Video Import.</source>
        <translation>Seçilen aygıt Video İçeri Aktar bölümünde &lt;b&gt;$VIDEODEVICE&lt;/b&gt; olarak görülüyor.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="354"/>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="354"/>
        <source>Description</source>
        <translation>Tanım</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="357"/>
        <source>&amp;Add</source>
        <translation>&amp;Ekle</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="358"/>
        <source>&amp;Remove</source>
        <translation>Çı&amp;kar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="359"/>
        <source>&amp;Edit</source>
        <translation>&amp;Düzenle</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="362"/>
        <source>Video device settings</source>
        <translation>Video aygıt ayarları</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="363"/>
        <source>Video Device ($VIDEODEVICE): </source>
        <translation>Video Aygıt ($VIDEODEVICE):(sp)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="149"/>
        <source>device</source>
        <translation>aygıt</translation>
    </message>
</context>
<context>
    <name>ExportTab</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="410"/>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="410"/>
        <source>Description</source>
        <translation>Tanım</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="413"/>
        <source>&amp;Add</source>
        <translation>&amp;Ekle</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="414"/>
        <source>&amp;Remove</source>
        <translation>Çı&amp;kar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="415"/>
        <source>&amp;Edit</source>
        <translation>&amp;Düzenle</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="97"/>
        <source>Encoder settings</source>
        <translation>Kodlayıcı ayarları</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="418"/>
        <source>Do you want to be asked for an output file everytime you choose to export?</source>
        <translation>Dışarı aktar seçeneğini her kullanışınızda hangi dosyaya yazacağınızın sorulmasını ister misiniz?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="420"/>
        <source>Yes</source>
        <translation>Evet</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="421"/>
        <source>No</source>
        <translation>Hayır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="422"/>
        <source>Set default output file:</source>
        <translation>Öntanımlı çıktı dosyası:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="423"/>
        <source>Browse</source>
        <translation>Tara</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="424"/>
        <source>Start encoder:</source>
        <translation>Kodlamaya başla:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="425"/>
        <source>Stop encoder:</source>
        <translation>Kodlamayı durdur:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="391"/>
        <source>Choose output file</source>
        <translation>Çıktı dosyasını seç</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="402"/>
        <source>Below you can set which program/process Stopmotion should use for encoding the currently active project to a video file.</source>
        <translation>Aşağıda şu an çalıştığınız projenin video olarak kaydedilmesi için hangi programın kullanılmasını istediğinizi belirleyebilirsiniz.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="404"/>
        <source>You should always use &lt;b&gt;$IMAGEPATH&lt;/b&gt; and &lt;b&gt;$VIDEOFILE&lt;/b&gt; to represent the image path and the video file, respectively.</source>
        <translation>Resimlerin yeri ve video dosyası için her zaman bir &lt;b&gt;$IMAGEPATH&lt;/b&gt; ve &lt;b&gt;$VIDEOFILE&lt;/b&gt; belirlemelisiniz.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="405"/>
        <source>Example with mencoder (jpeg images to mpeg4 video):</source>
        <translation>mencoder için örnek (jpeg images to mpeg4 video):</translation>
    </message>
</context>
<context>
    <name>ExternalCommand</name>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="44"/>
        <source>Input to program:</source>
        <translation>Programa girdi:</translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="54"/>
        <source>Submit</source>
        <translation>Gönder</translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="60"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="73"/>
        <source>Output from external command</source>
        <translation>Çalıştırılan komutun çıktısı</translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="116"/>
        <source>Result</source>
        <translation>Sonuç</translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="113"/>
        <source>Failed!</source>
        <translation>Olmadı!</translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="116"/>
        <source>Successfull!</source>
        <translation>Tamamdır!</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.ui" line="33"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
<context>
    <name>FrameBar</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framebar/framebar.cpp" line="125"/>
        <source>Frame number: </source>
        <translation>Kare sayısı:(sp)</translation>
    </message>
</context>
<context>
    <name>FramePreferencesMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="109"/>
        <source>Add &amp;sound</source>
        <translation>&amp;Ses ekle</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="110"/>
        <source>&amp;Remove Sound</source>
        <translation>S&amp;esi kaldır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="111"/>
        <source>Change name</source>
        <translation>İsmi değiştir</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="112"/>
        <source>Sounds:</source>
        <translation>Sesler:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="118"/>
        <source>&lt;h4&gt;Add sound&lt;/h4&gt; &lt;p&gt;With this button you can &lt;em&gt;add sounds&lt;/em&gt; to the selected frame.&lt;/p&gt; &lt;p&gt;The sound will begin playing when this frame is shown and play until it is done.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Ses ekle&lt;/h4&gt; &lt;p&gt;Bu düğme ile seçili kare için&lt;em&gt;ses ekleyebilirsiniz&lt;/em&gt;.&lt;/p&gt; &lt;p&gt;Kare göründüğünde çalmaya başlayacaktır.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="125"/>
        <source>&lt;h4&gt;Remove sound&lt;/h4&gt; &lt;p&gt;With this button you can &lt;em&gt;remove&lt;/em&gt; the selected sound from this frame.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Sesi çıkar&lt;/h4&gt; &lt;p&gt;Bu düğme ile seçili karede çalan &lt;em&gt;sesi kapatırsınız&lt;/em&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="133"/>
        <source>&lt;h4&gt;Change name&lt;/h4&gt; &lt;p&gt;With this button you can change the name of the selected sound. &lt;BR&gt;The name of the sound has no other effect than making it easier work with the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;İsmi değiştir&lt;/h4&gt; &lt;p&gt;Bu düğmeyle seçili ses dosyasının ismini değiştirebilirsiniz. &lt;BR&gt;Sizin çalışırken dosyaları ayırt etmeniz dışında bir önemi yoktur.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="141"/>
        <source>&lt;h4&gt;Sounds&lt;/h4&gt; &lt;p&gt;This lists shows all the sounds connected to this frame.&lt;/p&gt;&lt;p&gt;The sounds will begin playing when this frame is shown and play until they are done.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Sesler&lt;/h4&gt; &lt;p&gt;Bu liste kareye bağlı tüm sesleri gösterir.&lt;/p&gt;&lt;p&gt;Sesler, karenin görünmesiyle birlikte sonuna dek çalar.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>FrameView</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="444"/>
        <source>Warning</source>
        <translation>Dikkat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="435"/>
        <source>Grabbing failed. This may happen if you try
to grab from an invalid device. Please check
your grabber settings in the preferences menu.</source>
        <translation>Yakalama başarısız. Bu durum, çalışmayan
bir aygıttan görüntü yakalamayı denediyseniz
olmuş olabilir. Seçenekler menüsünü kontrol edin.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="446"/>
        <source>You have to define an image grabber to use.
This can be set in the preferences menu.</source>
        <translation>Görüntü yakalama aygıtı belirlemelisiniz.
Seçenekler menüsünden yapabilirsiniz.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="372"/>
        <source>Pre poll command does not exists</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="386"/>
        <source>You do not have the given grabber installed on your system</source>
        <translation>Seçilen yakalama aygıtı sistemde bulunamıyor.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="360"/>
        <source>No video device selected in the preferences menu.</source>
        <translation>Seçenekler menüsünde video aygıtı belirlenmemiş.</translation>
    </message>
</context>
<context>
    <name>ImportTab</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="337"/>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="337"/>
        <source>Description</source>
        <translation>Tanım</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="340"/>
        <source>&amp;Add</source>
        <translation>&amp;Ekle</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="341"/>
        <source>&amp;Remove</source>
        <translation>&amp;Kaldır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="342"/>
        <source>&amp;Edit</source>
        <translation>&amp;Düzenle</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="344"/>
        <source>Import device settings</source>
        <translation>Aygıt ayarlarını içeri aktar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="345"/>
        <source>Pre-poll command</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="346"/>
        <source>Start deamon</source>
        <translation>Servisi başlat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="347"/>
        <source>Stop deamon</source>
        <translation>Servisi durdur</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="332"/>
        <source>Below you can set which program/process Stopmotion should use for grabbing images from the selected device.</source>
        <translation>Seçilen aygıttan görüntü aktarmak için kullanılacak programı aşağıdan seçebilirsiniz.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="334"/>
        <source>You should always use &lt;b&gt;$VIDEODEVICE&lt;/b&gt; and &lt;b&gt;$IMAGEFILE&lt;/b&gt; to represent the video device and the image file, respectively.</source>
        <translation>Resim dosyaları ve video aygıtı için her zaman bir &lt;b&gt;$IMAGEFILE&lt;/b&gt; ve &lt;b&gt;$VIDEODEVICE&lt;/b&gt; belirlemelisiniz.</translation>
    </message>
</context>
<context>
    <name>LanguageHandler</name>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="82"/>
        <source>English</source>
        <comment>This should be translated to the name of the language you are translating to, in that language. Example: English = Deutsch (Deutsch is &quot;German&quot; in German)</comment>
        <translation>Türkçe</translation>
    </message>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="60"/>
        <source>English</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="62"/>
        <source>&amp;Translation</source>
        <translation>Çe&amp;viri</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="16"/>
        <source>Stopmotion Help Browser</source>
        <translation>Stopmotion Yardım Dosyaları</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="40"/>
        <source>Backward</source>
        <translation>Geri</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="50"/>
        <source>Forward</source>
        <translation>İleri</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="86"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>MainWindowGUI</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="159"/>
        <source>Ready to rumble ;-)</source>
        <translation>Seyreyle gümbürtüyü ;-)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="473"/>
        <source>&amp;New</source>
        <translation>&amp;Yeni</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="474"/>
        <source>&amp;Open</source>
        <translation>&amp;Aç</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="561"/>
        <source>&lt;h4&gt;Open&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Opens&lt;/em&gt; a Stopmotion project file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Aç&lt;/h4&gt; &lt;p&gt;Bir Stopmotion proje dosyasını &lt;em&gt;açar&lt;/em&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="475"/>
        <source>&amp;Save</source>
        <translation>Kay&amp;det</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="476"/>
        <source>Save &amp;As</source>
        <translation>&amp;Farklı kaydet</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="479"/>
        <source>&amp;Quit</source>
        <translation>Çı&amp;kış</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="602"/>
        <source>&lt;h4&gt;Quit&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Quits&lt;/em&gt; the program.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Çıkış&lt;/h4&gt;&lt;p&gt; Programı &lt;em&gt;kapatır&lt;/em&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="504"/>
        <source>&amp;File</source>
        <translation>&amp;Dosya</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="480"/>
        <source>&amp;Undo</source>
        <translation>&amp;Geri al</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="613"/>
        <source>&lt;h4&gt;Undo&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Undoes&lt;/em&gt; your last operation. You can press undo several time to undo earlier operations.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Geri al&lt;/h4&gt; &lt;p&gt;En son yaptığınız hareketi &lt;em&gt;geri alır&lt;/em&gt;. Daha önceki bir pozisyona dönmek için bir çok kere basabilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="481"/>
        <source>Re&amp;do</source>
        <translation>&amp;Yenile</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="622"/>
        <source>&lt;h4&gt;Redo&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Redoes&lt;/em&gt; your last operation. You can press redo several times to redo several operations.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Yenile&lt;/h4&gt; &lt;p&gt;Son yaptığınız hareketi &lt;em&gt; tekrar eder&lt;/em&gt;. Hareketi tekrarlamak için bir çok kere basabilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="482"/>
        <source>Cu&amp;t</source>
        <translation>Ke&amp;s</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="631"/>
        <source>&lt;h4&gt;Cut&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Cuts&lt;/em&gt; the selected frames out of the animation and adds them to the clipboard so that you can paste them in somewhere else.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kes&lt;/h4&gt; &lt;p&gt;Seçili kareleri animasyondan &lt;em&gt;keser&lt;/em&gt; ve panoda saklar böylece bir başka projeye yapıştırabilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="483"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopyala</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="640"/>
        <source>&lt;h4&gt;Copy&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Copies&lt;/em&gt; the selected frames to the clipboard. You can then paste them in another place.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kopyala&lt;/h4&gt; &lt;p&gt;Seçilen kareleri panoya &lt;em&gt;kopyalar&lt;/em&gt;. Böylece başka projelerde de kullanabilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="484"/>
        <source>&amp;Paste</source>
        <translation>&amp;Yapıştır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="650"/>
        <source>&lt;h4&gt;Paste&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Pastes&lt;/em&gt; the frames which are currently in the clipboard into the selected location.&lt;/p&gt; &lt;p&gt;You can copy/cut images from another programs and then use this option to paste them into this animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Yapıştır&lt;/h4&gt; &lt;p&gt;Panoda bulunan kareleri, seçili kareye &lt;em&gt;yapıştırır&lt;/em&gt;. &lt;/p&gt;&lt;p&gt;Resimleri kes/kopyala yöntemiyle başka programlardan panoya atıp, bu komutla animasyona ekleyebilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="485"/>
        <source>&amp;Go to frame</source>
        <translation>&amp;Ka&amp;reye git</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="659"/>
        <source>&lt;h4&gt;Go to frame&lt;/h4&gt; &lt;p&gt;This will bring up a popup-menu at the bottom where you can choose a frame you want to &lt;em&gt;go to&lt;/em&gt;.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kareye git&lt;/h4&gt; &lt;p&gt;Bir pencere açarak gitmek istediğiniz kare numarasını sorar.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="533"/>
        <source>&amp;Edit</source>
        <translation>Dü&amp;zenle</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="528"/>
        <source>&amp;Settings</source>
        <translation>&amp;Seçenekler</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="487"/>
        <source>What&apos;s &amp;This</source>
        <translation>&amp;Bu nedir</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="679"/>
        <source>&lt;h4&gt;What&apos;s This&lt;/h4&gt; &lt;p&gt;This will give you a WhatsThis mouse cursor which can be used to bring up helpful information like this.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Bu nedir?&lt;/h4&gt; &lt;p&gt;Size soru işareti şeklinde bir imleç vererek bu metin gibi ufak açıklamalar için tıklamanızı sağlar.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="489"/>
        <source>&amp;About</source>
        <translation>&amp;Hakkında</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="697"/>
        <source>&lt;h4&gt;About&lt;/h4&gt; &lt;p&gt;This will display a small information box where you can read general information as well as the names of the developers behind this excellent piece of software.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Hakkında&lt;/h4&gt; Bu programı yaratan ekip hakkında bilgi ve programa ilişkin ayrıntıları okumanızı sağlayan bir bilgi ekranıdır.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="535"/>
        <source>&amp;Help</source>
        <translation>&amp;Yardım</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="745"/>
        <source>&lt;h4&gt;FrameBar&lt;/h4&gt; &lt;p&gt;In this area you can see the frames and scenes in the animations and build the animation by moving the them around.&lt;/p&gt;&lt;p&gt;You can switch to the next and the previous frame using the &lt;b&gt;arrow buttons&lt;/b&gt; or &lt;b&gt;x&lt;/b&gt; and &lt;b&gt;z&lt;/b&gt;&lt;/p&gt; </source>
        <translation>&lt;h4&gt;ÇerçeveAlanı&lt;/h4&gt; &lt;p&gt;Bu alanda, animasyondaki kare ve sahneleri görerek, yerlerini değiştirerek kurgu yapma imkanı bulursunuz.&lt;/p&gt;&lt;p&gt; Önceki ya da sonraki kareye &lt;b&gt;yön tuşları&lt;/b&gt; ya da &lt;b&gt;x&lt;/b&gt; ve &lt;b&gt;z&lt;/b&gt; ile geçebilirsiniz.&lt;/p&gt;(sp)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="735"/>
        <source>&lt;h4&gt;Tool menu&lt;/h4&gt; &lt;p&gt;This is the tool menu where most of the buttons and widgets you will need when working on stop motion animations are located.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Araç menüsü&lt;/h4&gt; &lt;p&gt;Bu menü animasyon yaparken ihtiyaç duyacağını çoğu düğme ve aracı bulabileceğiniz alandır.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="729"/>
        <source>&lt;h4&gt;Frame preferences menu&lt;/h4&gt; &lt;p&gt;In this menu you can set preferences for the selected frame/frames, such as &lt;b&gt;subtitles&lt;/b&gt;, &lt;b&gt;sound effects&lt;/b&gt;, etc.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kare seçenekleri menüsü&lt;/h4&gt; &lt;p&gt;Bu menüde seçili kare/lerin &lt;b&gt;altyazı&lt;/b&gt;, &lt;b&gt; ses efektleri&lt;/b&gt; gibi özelliklerini düzenleyebilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="722"/>
        <source>&lt;h4&gt;Go to frame menu&lt;/h4&gt; &lt;p&gt;Here you can specify a framenumber and the program will jump to the specified frame&lt;/p&gt; </source>
        <translation>&lt;h4&gt;Kareye git menüsü&lt;/h4&gt; &lt;p&gt;sıra numarası ile kare seçmenizi sağlar.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="494"/>
        <source>Go to frame:</source>
        <translation>Kareye git:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="707"/>
        <source>&lt;h4&gt;Frame number&lt;/h4&gt;&lt;p&gt;This area displays the numberof the currently selected frame&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kare sırası&lt;/h4&gt;&lt;p&gt;Bu alanda seçili karenin sıra numarasını görebilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="716"/>
        <source>&lt;h4&gt;FrameView&lt;/h4&gt;&lt;p&gt; In this area you can see the selected frame. You can also play animations in this window by pressing the &lt;b&gt;Play&lt;/b&gt; button.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kare izleme&lt;/h4&gt;&lt;p&gt; Bu alanda seçili kareyi görebilirsiniz. Aynı zamanda &lt;b&gt;Başlat&lt;/b&gt; düğmesiyle oynatabilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="755"/>
        <source>Unsaved changes</source>
        <translation>Kaydedilmeyen değişiklikler</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="756"/>
        <source>There are unsaved changes. Do you want to save?</source>
        <translation>Kaydedilmemiş değişiklikler var, kaydetmek ister misiniz?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="923"/>
        <source>&amp;Yes</source>
        <translation>&amp;Evet</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="923"/>
        <source>&amp;No</source>
        <translation>&amp;Hayır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="477"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="517"/>
        <source>&amp;Export</source>
        <translation>&amp;Dışarı aktar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="552"/>
        <source>&lt;h4&gt;New&lt;/h4&gt; &lt;p&gt;Creates a &lt;em&gt;new&lt;/em&gt; project.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Yeni&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Yeni&lt;/em&gt; bir proje açar.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="571"/>
        <source>&lt;h4&gt;Save&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Saves&lt;/em&gt; the current animation as a Stopmotion project file. &lt;BR&gt;If this project has been saved before it will automaticly be saved to the previously selected file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kaydet&lt;/h4&gt; &lt;p&gt;Animasyonu Stopmotion dosyası olarak kaydeder. Daha önce kaydedilmişse, önceki dosyanın üzerine yazar.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="580"/>
        <source>&lt;h4&gt;Save As&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Saves&lt;/em&gt; the current animation as a Stopmotion project file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Farklı kaydet&lt;/h4&gt; &lt;p&gt;Animasyonu yeni bir isimle Stopmotion projesi olarak kaydeder.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="589"/>
        <source>&lt;h4&gt;Video&lt;/h4&gt; &lt;p&gt;Exports the current project as &lt;em&gt;video&lt;/em&gt;.&lt;/p&gt;You will be given a wizard to guide you.</source>
        <translation>&lt;h4&gt;Video&lt;/h4&gt; &lt;p&gt;Bir sihirbaz yardımıyla, aktif projeyi &lt;em&gt;video&lt;/em&gt; olarak dışarı aktarır.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="596"/>
        <source>&lt;h4&gt;Cinerella&lt;/h4&gt; &lt;p&gt;Exports the current animation as a &lt;em&gt;Cinerella&lt;/em&gt; project.&lt;/p&gt;You will be given a wizard to guide you.</source>
        <translation>&lt;h4&gt;Cinerella&lt;/h4&gt; &lt;p&gt;Çalışılan projeyi &lt;em&gt;Cinerella&lt;/em&gt; projesi olarak kaydetmek için bir sihirbaz açar.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="478"/>
        <source>Cinelerra</source>
        <translation>Cinelerra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="486"/>
        <source>&amp;Configure Stopmotion</source>
        <translation>Stopmotion &amp;yapılandırma</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="1113"/>
        <source>Open &amp;Recent</source>
        <translation>Son &amp;açılanlar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="556"/>
        <source>New project</source>
        <translation>Yeni proje</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="564"/>
        <source>Open project</source>
        <translation>Proje aç</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="574"/>
        <source>Save project</source>
        <translation>Projeyi kaydet</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="583"/>
        <source>Save project As</source>
        <translation>Projeyi farklı kaydet</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="605"/>
        <source>Quit</source>
        <translation>Çıkış</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="616"/>
        <source>Undo</source>
        <translation>Geri al</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="625"/>
        <source>Redo</source>
        <translation>Tekrar et</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="634"/>
        <source>Cut</source>
        <translation>Kes</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="643"/>
        <source>Copy</source>
        <translation>Kopyala</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="653"/>
        <source>Paste</source>
        <translation>Yapıştır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="662"/>
        <source>Go to frame</source>
        <translation>Kareye git</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="668"/>
        <source>&lt;h4&gt;Configure Stopmotion&lt;/h4&gt; &lt;p&gt;This will opens a window where you can &lt;em&gt;configure&lt;/em&gt; Stopmotion with various input and output devices.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Stopmotion yapılandırma&lt;/h4&gt; &lt;p&gt;Stopmotion için yakalama/aktarma aygıtlarını ve programlarını seçebileceğiniz bir &lt;em&gt;yapılandırma&lt;/em&gt; penceresi açar.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="671"/>
        <source>Configure Stopmotion</source>
        <translation>Stopmotion Yapılandır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="682"/>
        <source>What&apos;s This</source>
        <translation>Nedir?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="700"/>
        <source>About</source>
        <translation>Hakkında</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="920"/>
        <source>Warning</source>
        <translation>Uyarı</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="871"/>
        <source>Cannot find any registered encoder to be used for
video export. This can be setted in the preferences
menu. Export to video will not be possible until you
have setted an encoder to use. Do you want to set it now?</source>
        <translation>Dışarı video aktarmak için seçili kodlayıcı bulunamadı.
Seçenekler bölümünde bu konuda bir bilgi girilene kadar
video aktarma yapılması mümkün olmayacak. Şimdi
belirlemek ister misiniz?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="901"/>
        <source>Export to video file</source>
        <translation>Video dosyasına aktar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="922"/>
        <source>The registered encoder is not valid. Do you want
to check your settings in the preferences menu?</source>
        <translation>Seçili kodlayıcı geçersiz. Seçenekler menüsünü
kontrol etmek ister misiniz?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="936"/>
        <source>Export to file</source>
        <translation>Dosyaya aktar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="687"/>
        <source>&lt;h4&gt;Help&lt;/h4&gt; &lt;p&gt;This button will bring up a dialog with the Stopmotion manual&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Yardım&lt;/h4&gt; &lt;p&gt;Bu düğme size Stopmotion el kitabını açar&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="690"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="493"/>
        <source>Frame number: </source>
        <translation>Kare sırası:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="778"/>
        <source>Choose project file</source>
        <translation>Proje dosyasını seç</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="837"/>
        <source>Save As</source>
        <translation>Farklı kaydet</translation>
    </message>
</context>
<context>
    <name>ModelHandler</name>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="53"/>
        <source>Choose frames to add</source>
        <translation>Eklenecek kareleri seçin</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="143"/>
        <source>Removed the selected frame</source>
        <translation>Seçili kareyi çıkar</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="216"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="184"/>
        <source>You do not have Gimp installed on your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="195"/>
        <source>There is no active frame to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="203"/>
        <source>The active frame is corrupt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="217"/>
        <source>Failed to start Gimp!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="116"/>
        <source>Video &amp;Import</source>
        <translation>İçeri Video Akt&amp;ar</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="117"/>
        <source>Video &amp;Export</source>
        <translation>Dışarı Video Akta&amp;r</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="111"/>
        <source>Apply</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="112"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="113"/>
        <source>Preferences Menu</source>
        <translation>Seçenek menüsü</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="115"/>
        <source>Video &amp;Device</source>
        <translation>Video Ay&amp;gıtı</translation>
    </message>
</context>
<context>
    <name>QtFrontend</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="152"/>
        <source>Warning</source>
        <translation>Dikkat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="156"/>
        <source>Fatal</source>
        <translation>Kritik</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="70"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="222"/>
        <source>vgrabbj VGA singleshot</source>
        <translation>vgrabbj VGA tek çekim</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="230"/>
        <source>vgrabbj VGA deamon</source>
        <translation>vgrabbj VGA servis</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="232"/>
        <source>Starts vgrabbj as a deamon. Pretty fast.</source>
        <translation>vgrabbj servis olarak başlat. Hız kazandırır.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="339"/>
        <source>Question</source>
        <translation>Soru</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="224"/>
        <source>The simplest setting. Fairly slow</source>
        <translation>Basit yapılandırma. Oldukça yavaştır.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="274"/>
        <source>Exports from jpeg images to mpeg1 video</source>
        <translation>jpeg görüntüleri mpeg1 video dosyasına aktarır.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="190"/>
        <source>A newer version of the preferences file with few more default
values exists. Do you want to use this one? (Your old preferences
 will be saved in ~/.stopmotion/preferences.xml.OLD)</source>
        <translation>Seçenekler dosyasının ön tanımlı bir kaç yeni değeri olan
yeni bir kopyası bulundu. Bunu kullanmak ister misiniz?
(Eski dosya ~/.stopmotion/preferences.xml.OLD olarak korunacak.)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="283"/>
        <source>Exports from jpeg images to mpeg2 video</source>
        <translation>jpeg görüntüleri mpeg2 video dosyasına aktarır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="301"/>
        <source>Exports from jpeg images to mpeg4 video</source>
        <translation>jpeg görüntüleri mpeg4 video dosyasına aktarır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="257"/>
        <source>dvgrab</source>
        <translation>dvgrab</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="241"/>
        <source>Grabbing from DV-cam. (EXPERIMENTAL)</source>
        <translation>DV-cam&apos;den aktarır. (Deneme aşamasında)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="249"/>
        <source>videodog singleshot</source>
        <translation>videodog tekçekim</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="251"/>
        <source>Videodog.</source>
        <translation>Videodog.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="259"/>
        <source>Grabbing from DV-cam.</source>
        <translation>DV-cam&apos;den aktarıyor.</translation>
    </message>
</context>
<context>
    <name>RunAnimationHandler</name>
    <message>
        <location filename="../src/application/runanimationhandler.cpp" line="90"/>
        <source>Running animation</source>
        <translation>Animasyonu oynat</translation>
    </message>
</context>
<context>
    <name>SoundHandler</name>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="45"/>
        <source>Sounds (*.ogg)</source>
        <translation>Sesler (*.ogg)</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="78"/>
        <source>Sound name</source>
        <translation>Ses dosyası adı</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="78"/>
        <source>Enter the name of the sound:</source>
        <translation>Ses dosyas için isim belirle:</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="45"/>
        <source>Choose sound file</source>
        <translation>Ses dosyasını seç</translation>
    </message>
</context>
<context>
    <name>ToolsMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="210"/>
        <source>FPS chooser</source>
        <translation>FPS (kare/saniye) seçimi </translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="294"/>
        <source>&lt;h4&gt;FPS chooser&lt;/h4&gt; &lt;p&gt;By changing the value in this chooser you set which speed the animation in the &lt;b&gt;FrameView&lt;/b&gt; should run at.&lt;/p&gt; &lt;p&gt;To start an animation press the &lt;b&gt;Run Animation&lt;/b&gt; button.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;FPS seçimi&lt;/h4&gt; &lt;p&gt;Bu değer ile, animasyonun &lt;b&gt;KareGöster&lt;/b&gt; ekranında oynayacağı hızı belirliyorsunuz.&lt;/p&gt; Animasyonu oynatmak için &lt;b&gt;Oynat&lt;/b&gt; düğmesine basın.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="211"/>
        <source>Number of images:</source>
        <translation>Görüntü sayısı:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="214"/>
        <source>Mix</source>
        <translation>Karıştır</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="215"/>
        <source>Diff</source>
        <translation>Fark</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="216"/>
        <source>Playback</source>
        <translation>Oynat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="230"/>
        <source>&lt;h4&gt;Add Frames (CTRL+F)&lt;/h4&gt; &lt;p&gt;Click on this button to &lt;em&gt;add&lt;/em&gt; frames to the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kare Ekle (CTRL+F)&lt;/h4&gt; &lt;p&gt;Bu düğmeyle animasyona kare &lt;em&gt;ekleyebilirsiniz&lt;/em&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="237"/>
        <source>&lt;h4&gt;Remove Selection (Delete)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;remove&lt;/em&gt; the selected frames from the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Seçimi sil (Sil/Del)&lt;/h4&gt; Bu düğmeyle seçili kareleri animasyondan &lt;em&gt;çıkarırsınız&lt;/em&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="244"/>
        <source>&lt;h4&gt;New Scene (CTRL+E)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;create&lt;/em&gt; a new &lt;em&gt;scene&lt;/em&gt; to the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Yeni Sahne (CTRL+E)&lt;/h4&gt; &lt;p&gt;Bu düğmeyle yeni bir &lt;em&gt;sahne yaratırsınız&lt;/em&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="251"/>
        <source>&lt;h4&gt;Remove Scene (SHIFT+Delete)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;remove&lt;/em&gt; the selected scene from the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Sahneyi sil (Shift + Del /Sil) &lt;/h4&gt; &lt;p&gt; Seçili sahneyi animasyondan silmek için bu düğmeyi kullanabilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="257"/>
        <source>&lt;h4&gt;Toggle camera on/off (C)&lt;/h4&gt; &lt;p&gt;Click this button to toggle the camera on and off&lt;/p&gt; </source>
        <translation>&lt;h4&gt;Kamerayı aç/kapa (C)&lt;/h4&gt; &lt;p&gt;Kamerayı açıp/kapamak için bu düğmeyi kullanabilirsiniz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="272"/>
        <source>&lt;h4&gt;Capture Frame (Space)&lt;/h4&gt; &lt;p&gt;Click on this button to &lt;em&gt;capture&lt;/em&gt; a frame from the camera an put it in the animation&lt;/p&gt; &lt;p&gt; This can also be done by pressing the &lt;b&gt;Space key&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="283"/>
        <source>&lt;h4&gt;Number of images&lt;/h4&gt; &lt;p&gt;By changing the value in this slidebar you can specify how many images backwards in the animation which should be mixed on top of the camera or if you are in playback mode: how many images to play. &lt;/p&gt; &lt;p&gt;By mixing the previous image(s) onto the camera you can more easily see how the next shot will be in relation to the other, therby making a smoother stop motion animation!&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="298"/>
        <source>&lt;h4&gt;Play animation (K, P)&lt;/h4&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="301"/>
        <source>&lt;h4&gt;Stop animation (K, P)&lt;/h4&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="304"/>
        <source>&lt;h4&gt;Previous frame (J, Left)&lt;/h4&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="307"/>
        <source>&lt;h4&gt;Next frame (L, Right)&lt;/h4&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="310"/>
        <source>&lt;h4&gt;Previous scene (I)&lt;/h4&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="313"/>
        <source>&lt;h4&gt;Next scene (O)&lt;/h4&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="318"/>
        <source>&lt;h4&gt;Loop animation (CTRL+L)&lt;/h4&gt; &lt;p&gt;With this button you can set whether you want the animation to play to the end, or to loop indefinetly.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="408"/>
        <source>Notice</source>
        <translation>Uyarı</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="411"/>
        <source>Playback only currently works when running the grabber 
as a deamon. Go to the preferences menu (CTRL+P) to switch 
to running the image grabbing as a deamon.</source>
        <translation>Şu anda, oynatma özeliği sadece yakalayıcıyı servis olarak
çalıştırdığınızda kullanabilirsiniz. Seçenekler menüsüne (CTRL-P)
gidip görüntü yakalamayı servis olarak açabilirsiniz.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="217"/>
        <source>Auto</source>
        <translation>Otomatik</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="221"/>
        <source>Pr sec</source>
        <translation>Pr sn</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="222"/>
        <source>Pr min</source>
        <translation>Pr dk</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="223"/>
        <source>Pr hr</source>
        <translation>Pr saat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="264"/>
        <source>&lt;h4&gt;Launch Gimp&lt;/h4&gt; &lt;p&gt;Click this button to open the active frame in Gimp&lt;/p&gt; &lt;p&gt;Note that you can also drag images from the frame bar and drop them on Gimp&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
