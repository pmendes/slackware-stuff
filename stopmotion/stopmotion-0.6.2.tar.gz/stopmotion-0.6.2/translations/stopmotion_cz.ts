<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="44"/>
        <source>&amp;About</source>
        <translation type="unfinished">O programu</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="47"/>
        <source>Main developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="52"/>
        <source>A&amp;uthors</source>
        <translation type="unfinished">Autoři</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="56"/>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="57"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="58"/>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="59"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="65"/>
        <source>Logo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="67"/>
        <source>Coordinating</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="70"/>
        <source>Testing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="81"/>
        <source>&amp;Thanks To</source>
        <translation type="unfinished">Poděkování</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="86"/>
        <source>&amp;Licence Agreement</source>
        <translation type="unfinished">Licenční podmínky</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="88"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="101"/>
        <source>About</source>
        <translation type="unfinished">O programu</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="40"/>
        <source>This is the Stopmotion application for creating stop motion animations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="60"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="61"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="62"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="63"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/aboutdialog.cpp" line="50"/>
        <source>Contributors</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceTab</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="346"/>
        <source>Below you can set which device Stopmotion should use for grabbing images and displaying video.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="349"/>
        <source>You can select from the auto-detected devices below or add devices yourself. It is not recommended to use devices which is not auto-detected, but feel free to do it if you are an advanced user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="351"/>
        <source>The selected device is recognized as &lt;b&gt;$VIDEODEVICE&lt;/b&gt; under Video Import.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="354"/>
        <source>Name</source>
        <translation type="unfinished">Název</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="354"/>
        <source>Description</source>
        <translation type="unfinished">Popis</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="357"/>
        <source>&amp;Add</source>
        <translation type="unfinished">Přid&amp;at</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="358"/>
        <source>&amp;Remove</source>
        <translation type="unfinished">&amp;Smazat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="359"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="362"/>
        <source>Video device settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="363"/>
        <source>Video Device ($VIDEODEVICE): </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/devicetab.cpp" line="149"/>
        <source>device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportTab</name>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;Below you can set which program/process stopmotion should use for encoding the currently active project to a video file.&lt;/p&gt;&lt;p&gt;You can use $IMAGEPATH to represent the image path (absolute path to the directory where the images can be found). You should always use &lt;b&gt;$VIDEOFILE&lt;/b&gt; to represent the output file (the videofile generated by the encoder) in the &lt;b&gt;command line&lt;/b&gt;. This is independent of how you decides to select it (select it for each export or have a default file).&lt;br&gt;&lt;/p&gt;&lt;p&gt; Example with mencoder (converting jpg to mpeg1): &lt;br&gt;mencoder mf://$IMAGEPATH/*.jpg -mf w=640:h=480:fps=12:type=jpg -ovc lavc -lavcopts vcodec=mpeg1video -oac copy -o $VIDEOFILE &lt;br&gt;</source>
        <translation type="obsolete">&lt;p&gt;Zde můžete nastavit jaký program/proces má stopmotion používat pro kódování právě aktivního projektu do video souboru.&lt;/p&gt; Můžete použít &lt;b&gt;$IMAGEPATH&lt;/b&gt; pro nastavení absolutní cesty k adresáři s obrázky. Vždy byste měli nastavit &lt;b&gt;$VIDEOFILE&lt;/b&gt; pro nastavení výstupního souboru (video soubor generovaný enkodérem) v &lt;b&gt;příkazové řádce&lt;/b&gt;. Toto nastaveníje nezávislé na tom, jestli vybíráte pokaždé výstupní soubor nebo máte výchozí soubor pro export.&lt;br&gt;&lt;/p&gt;&lt;p&gt; Příklad s mencoderem (konverze jpg do mpeg1): &lt;br&gt;mencoder mf://$IMAGEPATH/*.jpg -mf w=640:h=480:fps=12:type=jpg -ovc lavc -lavcopts vcodec=mpeg1video -oac copy -o $VIDEOFILE &lt;br&gt;</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Active</source>
        <translation type="obsolete">Aktivní</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="410"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="410"/>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="413"/>
        <source>&amp;Add</source>
        <translation>Přid&amp;at</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="414"/>
        <source>&amp;Remove</source>
        <translation>&amp;Smazat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="415"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editovat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="97"/>
        <source>Encoder settings</source>
        <translation>Nastavení enkodéru</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="418"/>
        <source>Do you want to be asked for an output file everytime you choose to export?</source>
        <translation>Chcete pokaždé při exportu zvolit výstupní soubor?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="420"/>
        <source>Yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="421"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="422"/>
        <source>Set default output file:</source>
        <translation>Výchozí výstupní soubor:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="423"/>
        <source>Browse</source>
        <translation>Procházet</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="424"/>
        <source>Start encoder:</source>
        <translation>Spustit enkodér:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="425"/>
        <source>Stop encoder:</source>
        <translation>Zastavit enkodér:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="391"/>
        <source>Choose output file</source>
        <translation>Výstupní soubor</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="402"/>
        <source>Below you can set which program/process Stopmotion should use for encoding the currently active project to a video file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="404"/>
        <source>You should always use &lt;b&gt;$IMAGEPATH&lt;/b&gt; and &lt;b&gt;$VIDEOFILE&lt;/b&gt; to represent the image path and the video file, respectively.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/exporttab.cpp" line="405"/>
        <source>Example with mencoder (jpeg images to mpeg4 video):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExternalCommand</name>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="44"/>
        <source>Input to program:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="54"/>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="60"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="73"/>
        <source>Output from external command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="116"/>
        <source>Result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="113"/>
        <source>Failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/externalcommand.cpp" line="116"/>
        <source>Successfull!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDialog</name>
    <message>
        <location filename="" line="7471221"/>
        <source>Go to home directory</source>
        <translation type="obsolete">Domovský adresář (~)</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.ui" line="33"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameBar</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framebar/framebar.cpp" line="125"/>
        <source>Frame number: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FramePreferencesMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="109"/>
        <source>Add &amp;sound</source>
        <translation>Přidat &amp;zvuk</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="110"/>
        <source>&amp;Remove Sound</source>
        <translation>S&amp;mazat zvuk</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="111"/>
        <source>Change name</source>
        <translation>Přejmenovat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="112"/>
        <source>Sounds:</source>
        <translation>Zvuky:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="118"/>
        <source>&lt;h4&gt;Add sound&lt;/h4&gt; &lt;p&gt;With this button you can &lt;em&gt;add sounds&lt;/em&gt; to the selected frame.&lt;/p&gt; &lt;p&gt;The sound will begin playing when this frame is shown and play until it is done.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Přidat zvuk&lt;/h4&gt;&lt;p&gt;Tímto tlačítkem můžete &lt;em&gt;přidat zvuky&lt;/em&gt; k právě vybranému rámu. &lt;p&gt;Zvuk se začne přehrávat ve chvíli zobrazení tohoto rámu.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="125"/>
        <source>&lt;h4&gt;Remove sound&lt;/h4&gt; &lt;p&gt;With this button you can &lt;em&gt;remove&lt;/em&gt; the selected sound from this frame.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Smazat zvuk&lt;/h4&gt;&lt;p&gt;Tímto tlačítkem můžete &lt;em&gt;odebrat&lt;/em&gt; vybraný zvuk z tohoto rámu.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="133"/>
        <source>&lt;h4&gt;Change name&lt;/h4&gt; &lt;p&gt;With this button you can change the name of the selected sound. &lt;BR&gt;The name of the sound has no other effect than making it easier work with the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Přejmenovat&lt;/h4&gt; &lt;p&gt;Tímto tlačítkem můžete změnit název vybraného zvuku. &lt;br&gt;Nebude to mít žádný vliv na práci programu, ale pokud zvolíte vhodný název, bude se vám lépe pracovat s animací.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/framepreferencesmenu.cpp" line="141"/>
        <source>&lt;h4&gt;Sounds&lt;/h4&gt; &lt;p&gt;This lists shows all the sounds connected to this frame.&lt;/p&gt;&lt;p&gt;The sounds will begin playing when this frame is shown and play until they are done.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Zvuky&lt;/h4&gt;&lt;p&gt;V tomto seznamu jsou všechny zvuky přidané k tomuto rámu.&lt;/p&gt;&lt;p&gt;Zvuk se začne přehrávat ve chvíli zobrazení tohoto rámu.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>FrameView</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="444"/>
        <source>Warning</source>
        <translation>Varování</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="435"/>
        <source>Grabbing failed. This may happen if you try
to grab from an invalid device. Please check
your grabber settings in the preferences menu.</source>
        <translation>Grabování selhalo. To se může stát když zkoušíte
grabovat z neplatného zařízení. Prosím zkontrolujte
nastavení grabberu v menu Nastavení.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="446"/>
        <source>You have to define an image grabber to use.
This can be set in the preferences menu.</source>
        <translation>Musíte vybrat (v menu Nastavení) grabovací program, který
chcete používat.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="372"/>
        <source>Pre poll command does not exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="386"/>
        <source>You do not have the given grabber installed on your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/frameview.cpp" line="360"/>
        <source>No video device selected in the preferences menu.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HelpWindow</name>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;New Window</source>
        <translation type="obsolete">&amp;Nové okno</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Open File</source>
        <translation type="obsolete">&amp;Otevřít soubor</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Print</source>
        <translation type="obsolete">&amp;Tisk</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Close</source>
        <translation type="obsolete">&amp;Zavřít</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Backward</source>
        <translation type="obsolete">&amp;Zpět</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Forward</source>
        <translation type="obsolete">&amp;Dopředu</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Home</source>
        <translation type="obsolete">&amp;Domů</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Add Bookmark</source>
        <translation type="obsolete">Přidat záložku</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;File</source>
        <translation type="obsolete">&amp;Soubor</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Go</source>
        <translation type="obsolete">&amp;Jít</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>History</source>
        <translation type="obsolete">Historie</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Bookmarks</source>
        <translation type="obsolete">Záložky</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Backward</source>
        <translation type="obsolete">Zpět</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Forward</source>
        <translation type="obsolete">Dopředu</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Home</source>
        <translation type="obsolete">Domů</translation>
    </message>
</context>
<context>
    <name>ImportTab</name>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;Below you can set which program/process stopmotion should use for grabbing images from the webcam, and displaying video.&lt;br&gt; &lt;br&gt; &lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;Zde můžete nastavit jaký program/proces (grabber) má stopmotion používat pro zachytávání videa z webkamery a jeho zobrazování.&lt;br&gt;&lt;br&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Active</source>
        <translation type="obsolete">Aktivní</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="337"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="337"/>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="340"/>
        <source>&amp;Add</source>
        <translation>Přid&amp;at</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="341"/>
        <source>&amp;Remove</source>
        <translation>&amp;Smazat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="342"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editovat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="344"/>
        <source>Import device settings</source>
        <translation>Importovat nastavení zařízení</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="345"/>
        <source>Pre-poll command</source>
        <translation>Pre-poll příkaz</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="346"/>
        <source>Start deamon</source>
        <translation>Spustit démona</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="347"/>
        <source>Stop deamon</source>
        <translation>Zastavit démona</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="332"/>
        <source>Below you can set which program/process Stopmotion should use for grabbing images from the selected device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/importtab.cpp" line="334"/>
        <source>You should always use &lt;b&gt;$VIDEODEVICE&lt;/b&gt; and &lt;b&gt;$IMAGEFILE&lt;/b&gt; to represent the video device and the image file, respectively.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LanguageHandler</name>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="60"/>
        <source>English</source>
        <translation>Czech</translation>
    </message>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="82"/>
        <source>English</source>
        <comment>This should be translated to the name of the language you are translating to, in that language. Example: English = Deutsch (Deutsch is &quot;German&quot; in German)</comment>
        <translation>Čeština</translation>
    </message>
    <message>
        <location filename="../src/application/languagehandler.cpp" line="62"/>
        <source>&amp;Translation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="16"/>
        <source>Stopmotion Help Browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="40"/>
        <source>Backward</source>
        <translation type="unfinished">Zpět</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="50"/>
        <source>Forward</source>
        <translation type="unfinished">Dopředu</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/helpbrowser.ui" line="86"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindowGUI</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="159"/>
        <source>Ready to rumble ;-)</source>
        <translation>Připravenej ;-)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="473"/>
        <source>&amp;New</source>
        <translation>&amp;Nový</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="474"/>
        <source>&amp;Open</source>
        <translation>&amp;Otevřít</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="475"/>
        <source>&amp;Save</source>
        <translation>&amp;Uložit</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="476"/>
        <source>Save &amp;As</source>
        <translation>Uložit j&amp;ako</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="477"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="478"/>
        <source>Cinelerra</source>
        <translation>Cinelerra</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="479"/>
        <source>&amp;Quit</source>
        <translation>&amp;Konec</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="480"/>
        <source>&amp;Undo</source>
        <translation>&amp;Zpět</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="481"/>
        <source>Re&amp;do</source>
        <translation>&amp;Znovu</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="482"/>
        <source>Cu&amp;t</source>
        <translation>V&amp;yjmout</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="483"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopírovat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="484"/>
        <source>&amp;Paste</source>
        <translation>&amp;Vložit</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="485"/>
        <source>&amp;Go to frame</source>
        <translation>&amp;Jít na rám</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="486"/>
        <source>&amp;Configure Stopmotion</source>
        <translation>&amp;Nastavení Stopmotion</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="487"/>
        <source>What&apos;s &amp;This</source>
        <translation>Co to je?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="535"/>
        <source>&amp;Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="489"/>
        <source>&amp;About</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Frame number: 0</source>
        <translation type="obsolete">Číslo rámu: 0</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="494"/>
        <source>Go to frame:</source>
        <translation>Jít na rám:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="504"/>
        <source>&amp;File</source>
        <translation>Soubor</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="1113"/>
        <source>Open &amp;Recent</source>
        <translation>Nedávno otevřené</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="517"/>
        <source>&amp;Export</source>
        <translation>Exportovat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="533"/>
        <source>&amp;Edit</source>
        <translation>Editovat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="528"/>
        <source>&amp;Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Languages</source>
        <translation type="obsolete">Jazyky</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="552"/>
        <source>&lt;h4&gt;New&lt;/h4&gt; &lt;p&gt;Creates a &lt;em&gt;new&lt;/em&gt; project.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Nový&lt;/h4&gt;&lt;p&gt;Vytvoří nový projekt&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="556"/>
        <source>New project</source>
        <translation>Nový projekt</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="561"/>
        <source>&lt;h4&gt;Open&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Opens&lt;/em&gt; a Stopmotion project file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Otevřit&lt;/h4&gt;&lt;p&gt;Otevře existující projekt&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="564"/>
        <source>Open project</source>
        <translation>Otevřít projekt</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="571"/>
        <source>&lt;h4&gt;Save&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Saves&lt;/em&gt; the current animation as a Stopmotion project file. &lt;BR&gt;If this project has been saved before it will automaticly be saved to the previously selected file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Uložit&lt;/h4&gt;&lt;p&gt;Uloží animaci do projektu Stopmotion. &lt;br&gt; Pokud byl tento projekt už dříve uložen, bude původní soubor automaticky přepsán novým.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="574"/>
        <source>Save project</source>
        <translation>Uložit projekt</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="580"/>
        <source>&lt;h4&gt;Save As&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Saves&lt;/em&gt; the current animation as a Stopmotion project file.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Uložit jako&lt;/h4&gt;&lt;p&gt;Uloží animaci do projektu Stopmotion.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="583"/>
        <source>Save project As</source>
        <translation>Uložit projekt jako....</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="589"/>
        <source>&lt;h4&gt;Video&lt;/h4&gt; &lt;p&gt;Exports the current project as &lt;em&gt;video&lt;/em&gt;.&lt;/p&gt;You will be given a wizard to guide you.</source>
        <translation>&lt;h4&gt;Video&lt;/h4&gt;&lt;p&gt;Export projektu do video souboru s pomocí průvodce.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="596"/>
        <source>&lt;h4&gt;Cinerella&lt;/h4&gt; &lt;p&gt;Exports the current animation as a &lt;em&gt;Cinerella&lt;/em&gt; project.&lt;/p&gt;You will be given a wizard to guide you.</source>
        <translation>&lt;h4&gt;Cinelerra&lt;/h4&gt;&lt;p&gt;Exportuje animaci do projektu programu Cinelerra (s pomocí průvosce)&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="602"/>
        <source>&lt;h4&gt;Quit&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Quits&lt;/em&gt; the program.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Konec&lt;/h4&gt;&lt;p&gt;Ukončí program&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="605"/>
        <source>Quit</source>
        <translation>Konec</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="613"/>
        <source>&lt;h4&gt;Undo&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Undoes&lt;/em&gt; your last operation. You can press undo several time to undo earlier operations.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Zpět&lt;/h4&gt;&lt;p&gt;Vrátí zpět poslední operaci. Může být použito několikrát po sobě.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="616"/>
        <source>Undo</source>
        <translation>Zpět</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="622"/>
        <source>&lt;h4&gt;Redo&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Redoes&lt;/em&gt; your last operation. You can press redo several times to redo several operations.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Znovu&lt;/h4&gt;&lt;p&gt;Provede znovu poslední operaci.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="625"/>
        <source>Redo</source>
        <translation>Znovu</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="631"/>
        <source>&lt;h4&gt;Cut&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Cuts&lt;/em&gt; the selected frames out of the animation and adds them to the clipboard so that you can paste them in somewhere else.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Vyjmout&lt;/h4&gt; &lt;p&gt;Odstraní vybrané rámy z animace a vloží je schránky, takže je můžete použít někde jinde.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="634"/>
        <source>Cut</source>
        <translation>Vyjmout</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="640"/>
        <source>&lt;h4&gt;Copy&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Copies&lt;/em&gt; the selected frames to the clipboard. You can then paste them in another place.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Kopírovat&lt;/h4&gt; &lt;p&gt;Zkopíruje vybrané rámy do schránky pro použití jinde.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="643"/>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="650"/>
        <source>&lt;h4&gt;Paste&lt;/h4&gt; &lt;p&gt;&lt;em&gt;Pastes&lt;/em&gt; the frames which are currently in the clipboard into the selected location.&lt;/p&gt; &lt;p&gt;You can copy/cut images from another programs and then use this option to paste them into this animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Vložit&lt;/h4&gt; &lt;p&gt;&lt;Vloží di animace rámy ze schránky.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="653"/>
        <source>Paste</source>
        <translation>Vložit</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="659"/>
        <source>&lt;h4&gt;Go to frame&lt;/h4&gt; &lt;p&gt;This will bring up a popup-menu at the bottom where you can choose a frame you want to &lt;em&gt;go to&lt;/em&gt;.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Jít na rám&lt;/h4&gt; &lt;p&gt;V okně, které se objeví dole, můžete určit číslo rámu, na který se chcete přesunout.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="662"/>
        <source>Go to frame</source>
        <translation>Jít na rám</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="668"/>
        <source>&lt;h4&gt;Configure Stopmotion&lt;/h4&gt; &lt;p&gt;This will opens a window where you can &lt;em&gt;configure&lt;/em&gt; Stopmotion with various input and output devices.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Nastavení Stopmotion&lt;/h4&gt; &lt;p&gt;Otevře okno, kde můžete konfigurovat vstup/výstup.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="671"/>
        <source>Configure Stopmotion</source>
        <translation>Nastavení Stopmotion</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="679"/>
        <source>&lt;h4&gt;What&apos;s This&lt;/h4&gt; &lt;p&gt;This will give you a WhatsThis mouse cursor which can be used to bring up helpful information like this.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Co to je&lt;/h4&gt; &lt;p&gt;Po najetí kurzorem na vybraný prvek se objeví informace (jako je tahle).&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="682"/>
        <source>What&apos;s This</source>
        <translation>Co to je</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="687"/>
        <source>&lt;h4&gt;Help&lt;/h4&gt; &lt;p&gt;This button will bring up a dialog with the Stopmotion manual&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Nápověda&lt;/h4&gt; &lt;p&gt;Manuál k programu Stopmotion.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="690"/>
        <source>Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="697"/>
        <source>&lt;h4&gt;About&lt;/h4&gt; &lt;p&gt;This will display a small information box where you can read general information as well as the names of the developers behind this excellent piece of software.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;O programu&lt;/h4&gt; &lt;p&gt;Zobrazí malé informační okno, kde si můžete přečíst  různé informace jako třeba jména autorů tohoto programu.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="700"/>
        <source>About</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="707"/>
        <source>&lt;h4&gt;Frame number&lt;/h4&gt;&lt;p&gt;This area displays the numberof the currently selected frame&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Číslo rámu&lt;/h4&gt;&lt;p&gt;Zde se zobrazuje číslo (pořadí) právě vybraného rámu.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="716"/>
        <source>&lt;h4&gt;FrameView&lt;/h4&gt;&lt;p&gt; In this area you can see the selected frame. You can also play animations in this window by pressing the &lt;b&gt;Play&lt;/b&gt; button.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;FrameView&lt;/h4&gt;&lt;p&gt;Tady vidíte právě vybraný rám. Také se zde po kliknutí na tlačítko &lt;b&gt;Přehrát&lt;/b&gt; přehrává animace.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="722"/>
        <source>&lt;h4&gt;Go to frame menu&lt;/h4&gt; &lt;p&gt;Here you can specify a framenumber and the program will jump to the specified frame&lt;/p&gt; </source>
        <translation>&lt;h4&gt;Jít na rám&lt;/h4&gt; &lt;p&gt;Zde můžete zadat číslo rámu, na který se má program přesunout.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="729"/>
        <source>&lt;h4&gt;Frame preferences menu&lt;/h4&gt; &lt;p&gt;In this menu you can set preferences for the selected frame/frames, such as &lt;b&gt;subtitles&lt;/b&gt;, &lt;b&gt;sound effects&lt;/b&gt;, etc.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Nastavení rámu&lt;/h4&gt; &lt;p&gt;V tomto menu můžete nastavit pro vybraný rám (nebo více rámů) věci jako &lt;b&gt;titulky&lt;/b&gt;, &lt;b&gt;zvuky&lt;/b&gt; atp.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="735"/>
        <source>&lt;h4&gt;Tool menu&lt;/h4&gt; &lt;p&gt;This is the tool menu where most of the buttons and widgets you will need when working on stop motion animations are located.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Nástroje&lt;/h4&gt; &lt;p&gt;V tomto menu je většina toho, co budete potřebovat při práci s animací.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="745"/>
        <source>&lt;h4&gt;FrameBar&lt;/h4&gt; &lt;p&gt;In this area you can see the frames and scenes in the animations and build the animation by moving the them around.&lt;/p&gt;&lt;p&gt;You can switch to the next and the previous frame using the &lt;b&gt;arrow buttons&lt;/b&gt; or &lt;b&gt;x&lt;/b&gt; and &lt;b&gt;z&lt;/b&gt;&lt;/p&gt; </source>
        <translation>&lt;h4&gt;FrameBar&lt;/h4&gt; &lt;p&gt;V této oblasti vidíte rámy a scény vaší animace. Animaci můžete měnit posunem rámů.&lt;/p&gt;&lt;p&gt;Pohyb mezi rámy je možný pomocí &lt;b&gt;kurzorových kláves (šipky)&lt;/b&gt; a také písmen &lt;b&gt;z&lt;/b&gt; a &lt;b&gt;x&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="755"/>
        <source>Unsaved changes</source>
        <translation>Neuložené změny</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="756"/>
        <source>There are unsaved changes. Do you want to save?</source>
        <translation>V animaci jsou neuložené změny. Chcete soubor uložit?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="923"/>
        <source>&amp;Yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="923"/>
        <source>&amp;No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Save File</source>
        <translation type="obsolete">Uložit soubor</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="920"/>
        <source>Warning</source>
        <translation>Varování</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="871"/>
        <source>Cannot find any registered encoder to be used for
video export. This can be setted in the preferences
menu. Export to video will not be possible until you
have setted an encoder to use. Do you want to set it now?</source>
        <translation>Nemůžu najít žádný enkodér pro export videa. Můžete ho
nastavit v menu &quot;Nastavení&quot;. Dokud tam žádný nenastavíte,
nebude export videa možný. Chcete ho nyní nastavit?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="901"/>
        <source>Export to video file</source>
        <translation>Export do video souboru</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="922"/>
        <source>The registered encoder is not valid. Do you want
to check your settings in the preferences menu?</source>
        <translation>Enkodér je neplatný. Chcete zobrazit nastavení?</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="936"/>
        <source>Export to file</source>
        <translation>Export do souboru</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;This is the stopmotion application for creating stopmotion animations.&lt;/p&gt;&lt;p&gt;(c) 2005, Fredrik Berg Kj&#xf8;lstad and Bj&#xf8;rn Erik Nilsen&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;Tohle je program Stopmotion pro vytváření &quot;stopmotion&quot; animací..&lt;/p&gt;&lt;p&gt;(c) 2005, Fredrik Berg Kjølstad a Bjørn Erik Nilsen&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;&lt;b&gt;Main developers&lt;/b&gt;&lt;br&gt;Fredrik Berg Kj&#xf8;lstad &amp;lt;fredrikbk@hotmail.com&amp;gt;&lt;br&gt;Bj&#xf8;rn Erik Nilsen &amp;lt;bjoern.nilsen@bjoernen.com&amp;gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&lt;b&gt;Hlavní vývojáři&lt;/b&gt;&lt;br&gt;Fredrik Berg Kjølstad &amp;lt;fredrikbk@hotmail.com&amp;gt;&lt;br&gt;Bjørn Erik Nilsen &amp;lt;bjoern.nilsen@bjoernen.com&amp;gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>A&amp;uthors</source>
        <translation type="obsolete">Autoři</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&lt;p&gt;&lt;b&gt;Coordinating&lt;/b&gt;&lt;br&gt;Herman Robak &amp;lt;herman@skolelinux.no&amp;gt;&lt;br&gt;&#xd8;yvind Kol&#xe5;s &amp;lt;pippin@gimp.org&amp;gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Testing&lt;/b&gt;&lt;br&gt;Tore Sinding Bekkedal &amp;lt;toresbe@ifi.uio.no&amp;gt;&lt;br&gt;Finn Arne Johansen &amp;lt;faj@bzz.no&amp;gt;&lt;br&gt;Halvor Borgen &amp;lt;halvor.borgen@hig.no&amp;gt;&lt;br&gt;Bj&#xf8;rn Are Hansen &amp;lt;post@bahansen.net&amp;gt;&lt;br&gt;John Steinar Bild&#xf8;y &amp;lt;johnsbil@haldenfriskole.no&amp;gt;&lt;br&gt;Ole-Anders Andreassen &amp;lt;ole-anders.andreassen@sunndal.kommune.no&amp;gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Translation&lt;/b&gt;&lt;br&gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&lt;b&gt;Spolupráce&lt;/b&gt;&lt;br&gt;Herman Robak &amp;lt;herman@skolelinux.no&amp;gt;&lt;br&gt;Øyvind Kolås &amp;lt;pippin@gimp.org&amp;gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Testování&lt;/b&gt;&lt;br&gt;Tore Sinding Bekkedal &amp;lt;toresbe@ifi.uio.no&amp;gt;&lt;br&gt;Finn Arne Johansen &amp;lt;faj@bzz.no&amp;gt;&lt;br&gt;Halvor Borgen &amp;lt;halvor.borgen@hig.no&amp;gt;&lt;br&gt;Bjørn Are Hansen &amp;lt;post@bahansen.net&amp;gt;&lt;br&gt;John Steinar Bildøy &amp;lt;johnsbil@haldenfriskole.no&amp;gt;&lt;br&gt;Ole-Anders Andreassen &amp;lt;ole-anders.andreassen@sunndal.kommune.no&amp;gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Překlad&lt;/b&gt;&lt;br&gt;Jiří Helebrant &amp;lt;helb@skatekralovice.com&amp;gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Thanks To</source>
        <translation type="obsolete">Poděkování</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Licence Agreement</source>
        <translation type="obsolete">Licenční podmínky</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Stopmotion User Manual</source>
        <translation type="obsolete">Manuál</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="493"/>
        <source>Frame number: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="778"/>
        <source>Choose project file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/mainwindowgui.cpp" line="837"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModelHandler</name>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="53"/>
        <source>Choose frames to add</source>
        <translation>Vyberte rámy, které se mají přidat</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="143"/>
        <source>Removed the selected frame</source>
        <translation>Smazat označený rám</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="216"/>
        <source>Warning</source>
        <translation type="unfinished">Varování</translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="184"/>
        <source>You do not have Gimp installed on your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="195"/>
        <source>There is no active frame to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="203"/>
        <source>The active frame is corrupt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/application/modelhandler.cpp" line="217"/>
        <source>Failed to start Gimp!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="116"/>
        <source>Video &amp;Import</source>
        <translation>Import videa</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="117"/>
        <source>Video &amp;Export</source>
        <translation>Export videa</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="111"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="112"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="113"/>
        <source>Preferences Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/preferencesmenu.cpp" line="115"/>
        <source>Video &amp;Device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtFrontend</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="70"/>
        <source>Cancel</source>
        <translation>Storno</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>Progress</source>
        <translation type="obsolete">Průběh</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="152"/>
        <source>Warning</source>
        <translation>Varování</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="156"/>
        <source>Fatal</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="222"/>
        <source>vgrabbj VGA singleshot</source>
        <translation>vgrabbj VGA singleshot</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="224"/>
        <source>The simplest setting. Fairly slow</source>
        <translation>Nejjednodušší nastavení. Poměrně pomalé...</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="230"/>
        <source>vgrabbj VGA deamon</source>
        <translation>vgrabbj VGA démon</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="232"/>
        <source>Starts vgrabbj as a deamon. Pretty fast.</source>
        <translation>Startuje vgrabbj jako démona. Poměrně rychlé....</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="274"/>
        <source>Exports from jpeg images to mpeg1 video</source>
        <translation>Exportuje z obrázků (jpeg) do videa (mpeg1)</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>mencoder mf://$IMAGEPATH/*.jpg -mf w=640:h=480:fps=12:type=jpg -ovc lavc -lavcopts vcodec=mpeg1video -oac copy -o $VIDEOFILE</source>
        <translation type="obsolete">&lt;p&gt;&lt;b&gt;Main developers&lt;/b&gt;&lt;br&gt;Fredrik Berg Kjølstad &amp;lt;fredrikbk@hotmail.com&amp;gt;&lt;br&gt;Bjørn Erik Nilsen &amp;lt;bjoern.nilsen@bjoernen.com&amp;gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="339"/>
        <source>Question</source>
        <translation>Otázka</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;Yes</source>
        <translation type="obsolete">&amp;Ano</translation>
    </message>
    <message>
        <location filename="" line="7471221"/>
        <source>&amp;No</source>
        <translation type="obsolete">&amp;Ne</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="190"/>
        <source>A newer version of the preferences file with few more default
values exists. Do you want to use this one? (Your old preferences
 will be saved in ~/.stopmotion/preferences.xml.OLD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="283"/>
        <source>Exports from jpeg images to mpeg2 video</source>
        <translation type="unfinished">Exportuje z obrázků (jpeg) do videa (mpeg2)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="301"/>
        <source>Exports from jpeg images to mpeg4 video</source>
        <translation type="unfinished">Exportuje z obrázků (jpeg) do videa (mpeg4)</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="257"/>
        <source>dvgrab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="241"/>
        <source>Grabbing from DV-cam. (EXPERIMENTAL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="249"/>
        <source>videodog singleshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="251"/>
        <source>Videodog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/qtfrontend.cpp" line="259"/>
        <source>Grabbing from DV-cam.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RunAnimationHandler</name>
    <message>
        <location filename="../src/application/runanimationhandler.cpp" line="90"/>
        <source>Running animation</source>
        <translation>Přehrávání animace</translation>
    </message>
</context>
<context>
    <name>SoundHandler</name>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="45"/>
        <source>Sounds (*.ogg)</source>
        <translation>Zvuky (*.ogg)</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="78"/>
        <source>Sound name</source>
        <translation>Název zvuku</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="78"/>
        <source>Enter the name of the sound:</source>
        <translation>Vložte název pro zvuk:</translation>
    </message>
    <message>
        <location filename="../src/application/soundhandler.cpp" line="45"/>
        <source>Choose sound file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolsMenu</name>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="210"/>
        <source>FPS chooser</source>
        <translation>Výběr FPS</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="211"/>
        <source>Number of images:</source>
        <translation>Počet obrázků:</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="214"/>
        <source>Mix</source>
        <translation>Mix</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="215"/>
        <source>Diff</source>
        <translation>Rozdíl</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="216"/>
        <source>Playback</source>
        <translation>Přehrávání</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="230"/>
        <source>&lt;h4&gt;Add Frames (CTRL+F)&lt;/h4&gt; &lt;p&gt;Click on this button to &lt;em&gt;add&lt;/em&gt; frames to the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Přidat rámy&lt;/h4&gt; &lt;p&gt;Kliknutím na toto tlačítko můžete přidat rámy do vaší animace.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="237"/>
        <source>&lt;h4&gt;Remove Selection (Delete)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;remove&lt;/em&gt; the selected frames from the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Smazat výběr&lt;/h4&gt; &lt;p&gt;Odstraní vybrané rámy z animace.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="244"/>
        <source>&lt;h4&gt;New Scene (CTRL+E)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;create&lt;/em&gt; a new &lt;em&gt;scene&lt;/em&gt; to the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Nová scéna&lt;/h4&gt; &lt;p&gt;Přidá novou scénu do vaší animace.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="251"/>
        <source>&lt;h4&gt;Remove Scene (SHIFT+Delete)&lt;/h4&gt; &lt;p&gt;Click this button to &lt;em&gt;remove&lt;/em&gt; the selected scene from the animation.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Smazat scénu&lt;/h4&gt; &lt;p&gt;Odstraní vybranou scénu z animace.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="257"/>
        <source>&lt;h4&gt;Toggle camera on/off (C)&lt;/h4&gt; &lt;p&gt;Click this button to toggle the camera on and off&lt;/p&gt; </source>
        <translation>&lt;h4&gt;Zapnout/vypnout kameru&lt;/h4&gt; &lt;p&gt;Zapne nebo vypne vstup z kamery.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="272"/>
        <source>&lt;h4&gt;Capture Frame (Space)&lt;/h4&gt; &lt;p&gt;Click on this button to &lt;em&gt;capture&lt;/em&gt; a frame from the camera an put it in the animation&lt;/p&gt; &lt;p&gt; This can also be done by pressing the &lt;b&gt;Space key&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Zachytit rám&lt;/h4&gt; &lt;p&gt;Kliknutí na toto tlačítko přidá obraz z kamery do animace.&lt;/p&gt; &lt;p&gt;Mnohem rychleji to jde &lt;b&gt;mezerníkem&lt;/b&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="283"/>
        <source>&lt;h4&gt;Number of images&lt;/h4&gt; &lt;p&gt;By changing the value in this slidebar you can specify how many images backwards in the animation which should be mixed on top of the camera or if you are in playback mode: how many images to play. &lt;/p&gt; &lt;p&gt;By mixing the previous image(s) onto the camera you can more easily see how the next shot will be in relation to the other, therby making a smoother stop motion animation!&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Počet obrázků&lt;/h4&gt; &lt;p&gt;Změnou hodnoty můžete nastavit kolik obrázků (směrem zpět) v animaci má být přidáno na kameru nebo kolik se jich má přehrát (při přehrávání)&lt;/p&gt; &lt;p&gt;Přidání obrázku (nebo obrázků) na kameru můžete snadněji vidět vztah dalšího rámu k ostatním a vytvořit tak plynulejší animaci!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="294"/>
        <source>&lt;h4&gt;FPS chooser&lt;/h4&gt; &lt;p&gt;By changing the value in this chooser you set which speed the animation in the &lt;b&gt;FrameView&lt;/b&gt; should run at.&lt;/p&gt; &lt;p&gt;To start an animation press the &lt;b&gt;Run Animation&lt;/b&gt; button.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Výběr FPS&lt;/h4&gt; &lt;p&gt;Zde můžete nastavit rychlost animace ve FrameViewu (ve snímcích za sekundu)&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="298"/>
        <source>&lt;h4&gt;Play animation (K, P)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Přehrát animaci&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="301"/>
        <source>&lt;h4&gt;Stop animation (K, P)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Zastavit animaci&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="304"/>
        <source>&lt;h4&gt;Previous frame (J, Left)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Předchozí rám&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="307"/>
        <source>&lt;h4&gt;Next frame (L, Right)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Další rám&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="310"/>
        <source>&lt;h4&gt;Previous scene (I)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Přechozí scéna&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="313"/>
        <source>&lt;h4&gt;Next scene (O)&lt;/h4&gt;</source>
        <translation>&lt;h4&gt;Další scéna&lt;/h4&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="318"/>
        <source>&lt;h4&gt;Loop animation (CTRL+L)&lt;/h4&gt; &lt;p&gt;With this button you can set whether you want the animation to play to the end, or to loop indefinetly.&lt;/p&gt;</source>
        <translation>&lt;h4&gt;Přehrávat dokola&lt;/h4&gt;&lt;p&gt;Můžete určit, jestli se má animace přehrát jen jednou nebo stále opakovat dokola.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="408"/>
        <source>Notice</source>
        <translation>Poznámka</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="411"/>
        <source>Playback only currently works when running the grabber 
as a deamon. Go to the preferences menu (CTRL+P) to switch 
to running the image grabbing as a deamon.</source>
        <translation>Přehrávání nyní funguje pouze když grabber běží jako démon.
Toho můžete docílit v menu &quot;Nastavení&quot;.</translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="217"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="221"/>
        <source>Pr sec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="222"/>
        <source>Pr min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="223"/>
        <source>Pr hr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/presentation/frontends/qtfrontend/toolsmenu.cpp" line="264"/>
        <source>&lt;h4&gt;Launch Gimp&lt;/h4&gt; &lt;p&gt;Click this button to open the active frame in Gimp&lt;/p&gt; &lt;p&gt;Note that you can also drag images from the frame bar and drop them on Gimp&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
