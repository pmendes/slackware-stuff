#ifndef STRUCT_V4L_H
#define STRUCT_V4L_H

#ifdef __cplusplus
extern "C" {
#endif
	
extern char *bits_vid_cap[32];
extern char *bits_chan_flags[32];
extern char *desc_chan_type[];
extern char *bits_tuner_flags[32];
extern char *desc_tuner_mode[];
extern char *desc_pict_palette[];
extern char *bits_audio_flags[32];
extern char *bits_audio_mode[32];

extern struct struct_desc desc_video_capability[];
extern struct struct_desc desc_video_channel[];
extern struct struct_desc desc_video_tuner[];
extern struct struct_desc desc_video_picture[];
extern struct struct_desc desc_video_audio[];
extern struct struct_desc desc_video_window[];
extern struct struct_desc desc_video_buffer[];
extern struct struct_desc desc_video_mmap[];
extern struct struct_desc desc_video_mbuf[];

extern struct ioctl_desc ioctls_v4l1[256];

#ifdef __cplusplus
}
#endif

#endif /* STRUCT_V4L_H */
